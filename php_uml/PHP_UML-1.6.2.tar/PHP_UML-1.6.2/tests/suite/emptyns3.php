<?php
/**
 * Test-case (emptyns3.php) with an empty namespace
 * (it should not be ignored if appropriate switch was set in PHP_UML)
 *
 */
 
namespace SaggitariusStar;

interface BigBlackHole {};

?>