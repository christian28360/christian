<?php
/**
* @package PHP_UML::tests
*/
/**
* tests linking to methods and vars
*/
class a{
var $a;
function b(){}
var $c;
}

/**
* test links to methods and vars
*
* @see a::$a
* @see a::d()
*/
function a(){}
?>
