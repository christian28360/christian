<?php
/**
 * Test-case (emptyns6.php) with an empty namespace
 *
 * (it should not be ignored if appropriate switch was set in PHP_UML)
 *
 * Bla bla bla...
 */
 
namespace SaggitariusStar;

interface SecondBigBlackHole {};

?>