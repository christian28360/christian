<?php
namespace Vegetable\Cucumber;

use \Fruit;

class Peel {
	function test(Fruit\Seed $s) {
		return "Bingo !!";
	}
}


?>