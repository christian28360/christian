<?php
/**
 * Comment for namespace T
 */
namespace T;


class U {
}

/**
 * Comment for class V
 */
class V {
}
?>