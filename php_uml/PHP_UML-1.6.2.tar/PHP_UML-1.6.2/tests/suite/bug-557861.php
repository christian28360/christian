<?php
/**
* bug is fixed.  to test, remove this page-level docblock
* @package PHP_UML::tests
*/
/**
* this page will not be shown in the package list and should be
*@package PHP_UML::tests */
class bug557861
{
}
?>
