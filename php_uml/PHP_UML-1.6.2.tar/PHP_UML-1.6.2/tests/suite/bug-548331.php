<?php
/**
* @package PHP_UML::tests
* @subpackage notparsed
*/
/**
* @package PHP_UML::tests
* @subpackage notparsed
*/
class notseen
{
}
?>