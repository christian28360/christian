<?php
/**
 * Test-case (emptyns4.php) with 2 empty namespaces
 * (it should not be ignored if appropriate switch was set in PHP_UML)
 *
 */
 
namespace Level1\Level2\Level3\Level4 {

}

namespace Level1\Level2\Level3\Level5;
}
?>