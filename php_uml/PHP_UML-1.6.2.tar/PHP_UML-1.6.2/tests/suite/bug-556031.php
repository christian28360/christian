<?php
/**
* @package PHP_UML::tests
*/
/**
* @package PHP_UML::tests
*/
class mama
{}

?>