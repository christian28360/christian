<?php
/**
* @package PHP_UML::tests
*/
/**
* @package PHP_UML::tests
* @see b553607_Parser
*/
class b553607_Parser
{}
?>