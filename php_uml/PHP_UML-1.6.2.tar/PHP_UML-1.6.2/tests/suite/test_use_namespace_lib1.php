<?php
namespace Vegetable\SweetPepper;

use Fruit;

class Peel {
	function test(Fruit\Seed $s) {
		return "Bingo !!";
	}
}


?>