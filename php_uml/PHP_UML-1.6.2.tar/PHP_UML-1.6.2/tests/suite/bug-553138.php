<?php
/**
* @package PHP_UML::tests
*/
/**
* @package PHP_UML::tests
*/
class brokenlinkstovars
{
	var $broken;
	/**
	* @see $broken
	*/
	function brokenlinkstovars()
	{
	}
}
?>