<?php
/**
 * Test-case (emptyns5.php) with an empty namespace
 *
 * (it should not be ignored if appropriate switch was set in PHP_UML)
 *
 */
 
namespace Level1\Level2;

/**
 * Comment for the test interface
 *
 * Bla bla bla...
 */
interface test {
}

}

?>