<?php
/**
* @package PHP_UML::tests
*/
/**
* @package PHP_UML::tests
*/
class few
{
/******===really fancy===****
* my * is ignored
*/
var $pfh;
}
?>