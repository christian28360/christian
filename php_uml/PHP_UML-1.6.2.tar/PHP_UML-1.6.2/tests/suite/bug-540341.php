<?php
/** @package PHP_UML::tests */
/** @package PHP_UML::tests */
class bug540341
{
	function get_header2($atate)
	{
		$header2 .= '\'>First Page</a></td>';
	}
}
?>
