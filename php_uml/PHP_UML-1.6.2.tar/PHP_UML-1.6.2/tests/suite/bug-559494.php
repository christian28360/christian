<?php
/**
* tests variable names with the word 'array' in them
* @package PHP_UML::tests
*/
/**
* tests variable names with the word 'array' in them
* @package PHP_UML::tests
*/
class testarraybug
{
	var $arrayType = 'name should be arrayType';
	var $myarrayName = 'name should be myarrayName';
	/**
	* test with no default, should be arrayType1
	*/
	var $arrayType1    ;
	/**
	* test with no default, should be myarrayName1
	*/
	var $myarrayName1   ; 
}
?>