<?php
/**
* @package PHP_UML::tests
*/
/**
* 
*/
class baby extends mama
{
	var $oopsieindexing;
}
?>