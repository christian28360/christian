<?php
/**
 * Comment for namespace A\B
 */
namespace A\B;

include "test_namespace1.php";

/**
 * Comment for class R
 */
class R implements E, S {
}
	
interface S {
}

?>