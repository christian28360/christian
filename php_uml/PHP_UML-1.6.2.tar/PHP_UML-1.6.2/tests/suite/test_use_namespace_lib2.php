<?php

namespace Fruit {

	class SmallOrange implements Seed {
	}
	
	interface Seed {
	}

}
?>