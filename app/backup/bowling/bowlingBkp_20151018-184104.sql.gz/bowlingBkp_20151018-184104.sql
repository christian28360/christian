--
-- bowlingBkp_20151018-184104.sql.gz


DROP TABLE IF EXISTS `bowl_bowling`;
CREATE TABLE `bowl_bowling` (
  `bowl_bowling_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_bowling_nom` varchar(100) COLLATE latin1_general_cs NOT NULL,
  `bowl_bowling_commentaire` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_no` varchar(10) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_rue` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_alias` varchar(100) COLLATE latin1_general_cs DEFAULT NULL COMMENT 'ex. Bowling de Rambouillet',
  `bowl_bowling_adr_adr1` varchar(100) COLLATE latin1_general_cs DEFAULT NULL COMMENT 'compl�ment adresse 1',
  `bowl_bowling_adr_adr2` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_adr3` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_cp` mediumint(6) DEFAULT NULL,
  `bowl_bowling_adr_ville` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_pays` varchar(100) COLLATE latin1_general_cs DEFAULT 'France',
  `bowl_bowling_tel_1` varchar(15) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_tel_2` varchar(15) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_mail` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_web` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_created_on` datetime DEFAULT NULL,
  `bowl_bowling_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_bowling_id`),
  KEY `bowl_bowling_nom` (`bowl_bowling_nom`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `bowl_bowling` VALUES ('1','Chartres','Va bientôt fermer ?','28000',NULL,NULL,NULL,NULL,NULL,'127','Chartres','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','www.bowling.chartres.com\r\n',NULL,'2015-10-17 09:13:10');
INSERT INTO `bowl_bowling` VALUES ('2','Barjouville','Va déménager à l''Odyssée ?','28600','Pierre Missigaut',NULL,'Z.A. La Torche',NULL,NULL,'127','Barjouville','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','wwww.xbowl.com',NULL,'2015-10-18 15:01:54');
INSERT INTO `bowl_bowling` VALUES ('3','Saran',NULL,'45200',NULL,NULL,NULL,NULL,NULL,'127','Saran','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','www.bowling.chartres.com',NULL,'2015-10-18 15:01:29');
INSERT INTO `bowl_bowling` VALUES ('4','Olivet','C''est le bowling d''Orléans',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'France',NULL,NULL,NULL,NULL,'2015-10-17 09:11:22','2015-10-18 15:00:26');
INSERT INTO `bowl_bowling` VALUES ('5','Orléans','Situé à Olivet',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'France',NULL,NULL,NULL,NULL,'2015-10-18 15:01:12','2015-10-18 15:01:12');


DROP TABLE IF EXISTS `bowl_evenement`;
CREATE TABLE `bowl_evenement` (
  `bowl_evt_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_evt_code` varchar(10) COLLATE latin1_general_cs NOT NULL,
  `bowl_evt_bowl_id` int(11) DEFAULT NULL,
  `bowl_evt_typeJeu_id` int(11) DEFAULT NULL,
  `bowl_evt_formation_id` int(11) DEFAULT NULL,
  `bowl_evt_libelle` varchar(50) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_evt_created_on` datetime DEFAULT NULL,
  `bowl_evt_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_evt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `bowl_evenement` VALUES ('1','L',NULL,NULL,NULL,'Ligue jeudi','2015-10-18 17:57:03','2015-10-18 17:57:03');
INSERT INTO `bowl_evenement` VALUES ('2','E',NULL,NULL,NULL,'Entrainement','2015-10-18 17:57:41','2015-10-18 17:57:41');
INSERT INTO `bowl_evenement` VALUES ('3','LBM18',NULL,NULL,NULL,'Ligue Barjouville mardi 18h','2015-10-18 17:58:14','2015-10-18 17:58:14');
INSERT INTO `bowl_evenement` VALUES ('4','LBA20',NULL,NULL,NULL,'Ligue Barjouville mardi 18h','2015-10-18 17:58:47','2015-10-18 17:58:47');
INSERT INTO `bowl_evenement` VALUES ('5','e',NULL,NULL,NULL,'e','2015-10-18 17:59:46','2015-10-18 17:59:46');
INSERT INTO `bowl_evenement` VALUES ('6','e',NULL,NULL,NULL,'ee','2015-10-18 17:59:57','2015-10-18 17:59:57');


DROP TABLE IF EXISTS `bowl_formation`;
CREATE TABLE `bowl_formation` (
  `bowl_form_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_form_code` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_form_libelle` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_form_created_on` datetime DEFAULT NULL,
  `bowl_form_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_formation` VALUES ('1','3MH','Triplette mixte handicap','2015-10-18 18:07:08','2015-10-18 18:07:08');
INSERT INTO `bowl_formation` VALUES ('2','5S','Equipe de 5 scratch','2015-10-18 18:07:42','2015-10-18 18:07:42');
INSERT INTO `bowl_formation` VALUES ('3','1S','Individuel scratch','2015-10-18 18:08:11','2015-10-18 18:08:11');
INSERT INTO `bowl_formation` VALUES ('4','1Chon','Individuel catégorie honneur','2015-10-18 18:09:03','2015-10-18 18:09:03');
INSERT INTO `bowl_formation` VALUES ('5','2MH','Doublette mixte handicap','2015-10-18 18:09:59','2015-10-18 18:11:37');


DROP TABLE IF EXISTS `bowl_periode`;
CREATE TABLE `bowl_periode` (
  `bowl_periode_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_periode_dt_deb` datetime DEFAULT NULL,
  `bowl_periode_dt_fin` datetime DEFAULT NULL,
  `bowl_periode_libelle` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_periode_is_active` bit(1) DEFAULT NULL,
  `bowl_periode_created_on` datetime DEFAULT NULL,
  `bowl_periode_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_periode_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_periode` VALUES ('3','2015-09-01 00:00:00','2016-08-31 00:00:00','test manuel','1',NULL,NULL);
INSERT INTO `bowl_periode` VALUES ('6','2014-08-31 00:00:00','2015-09-01 00:00:00',NULL,NULL,'2015-10-18 18:30:17','2015-10-18 18:30:17');
INSERT INTO `bowl_periode` VALUES ('7','2016-01-01 00:00:00','2016-01-01 00:00:00','a virer',NULL,'2015-10-18 18:33:53','2015-10-18 18:33:53');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rr','2015-10-17 09:24:38','2015-10-18 15:04:00');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
