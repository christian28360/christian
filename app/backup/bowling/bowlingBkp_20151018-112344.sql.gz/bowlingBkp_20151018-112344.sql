--
-- bowlingBkp_20151018-112344.sql.gz


DROP TABLE IF EXISTS `bowl_bowling`;
CREATE TABLE `bowl_bowling` (
  `bowl_bowling_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_bowling_nom` varchar(100) COLLATE latin1_general_cs NOT NULL,
  `bowl_bowling_commentaire` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_no` varchar(10) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_rue` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_alias` varchar(100) COLLATE latin1_general_cs DEFAULT NULL COMMENT 'ex. Bowling de Rambouillet',
  `bowl_bowling_adr_adr1` varchar(100) COLLATE latin1_general_cs DEFAULT NULL COMMENT 'compl�ment adresse 1',
  `bowl_bowling_adr_adr2` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_adr3` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_cp` mediumint(6) DEFAULT NULL,
  `bowl_bowling_adr_ville` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_pays` varchar(100) COLLATE latin1_general_cs DEFAULT 'France',
  `bowl_bowling_tel_1` varchar(15) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_tel_2` varchar(15) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_mail` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_web` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_created_on` datetime DEFAULT NULL,
  `bowl_bowling_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_bowling_id`),
  KEY `bowl_bowling_nom` (`bowl_bowling_nom`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `bowl_bowling` VALUES ('1','Chartres','Va bientôt fermer ?','28000',NULL,NULL,NULL,NULL,NULL,'127','Chartres','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','www.bowling.chartres.com\r\n',NULL,'2015-10-17 09:13:10');
INSERT INTO `bowl_bowling` VALUES ('2','Barjouville','Va d�m�nager � l''Odyss�e ?','28600','Pierre Missigaut',NULL,'Z.A. La Torche',NULL,NULL,'127','Barjouville','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','wwww.xbowl.com',NULL,NULL);
INSERT INTO `bowl_bowling` VALUES ('3','Saran','','45200',NULL,NULL,NULL,NULL,NULL,'127','Saran','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','www.bowling.chartres.com',NULL,NULL);
INSERT INTO `bowl_bowling` VALUES ('4','Olivet','éàçê',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'France',NULL,NULL,NULL,NULL,'2015-10-17 09:11:22','2015-10-17 09:11:22');


DROP TABLE IF EXISTS `bowl_periode`;
CREATE TABLE `bowl_periode` (
  `bowl_periode_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_periode_dt_deb` date DEFAULT NULL,
  `bowl_periode_dt_fin` date DEFAULT NULL,
  `bowl_periode_libelle` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_periode_created_on` date DEFAULT NULL,
  `bowl_periode_updated_on` date NOT NULL,
  PRIMARY KEY (`bowl_periode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','Autre',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','tt','2015-10-17 09:24:38','2015-10-17 09:24:38');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','z','2015-10-17 09:25:05','2015-10-17 09:25:05');
