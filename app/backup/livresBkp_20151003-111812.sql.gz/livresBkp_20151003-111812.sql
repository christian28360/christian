--
-- livresBkp_20151003-111812.sql.gz


DROP TABLE IF EXISTS `liv_auteur`;
CREATE TABLE `liv_auteur` (
  `liv_aut_livre_id` int(11) NOT NULL,
  `liv_aut_ecri_id` int(11) NOT NULL,
  PRIMARY KEY (`liv_aut_livre_id`,`liv_aut_ecri_id`),
  KEY `FK_liv_ecri_id` (`liv_aut_ecri_id`),
  CONSTRAINT `FK_livre_id` FOREIGN KEY (`liv_aut_livre_id`) REFERENCES `liv_livre` (`livre_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_liv_ecri_id` FOREIGN KEY (`liv_aut_ecri_id`) REFERENCES `liv_ecrivain` (`liv_ecri_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_auteur` VALUES ('5','29');
INSERT INTO `liv_auteur` VALUES ('7','29');
INSERT INTO `liv_auteur` VALUES ('5','31');
INSERT INTO `liv_auteur` VALUES ('6','31');
INSERT INTO `liv_auteur` VALUES ('7','31');
INSERT INTO `liv_auteur` VALUES ('7','32');
INSERT INTO `liv_auteur` VALUES ('7','34');


DROP TABLE IF EXISTS `liv_couverture`;
CREATE TABLE `liv_couverture` (
  `liv_couv_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_couv_libelle` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_couv_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `liv_couv_updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`liv_couv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_couverture` VALUES ('1','Souple','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_couverture` VALUES ('2','Cartonnée','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_couverture` VALUES ('3','Rigide','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_couverture` VALUES ('4','Avec rabat','0000-00-00 00:00:00','0000-00-00 00:00:00');


DROP TABLE IF EXISTS `liv_ecrivain`;
CREATE TABLE `liv_ecrivain` (
  `liv_ecri_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_ecri_nom` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_ecri_prenom` varchar(100) CHARACTER SET latin1 DEFAULT '',
  `liv_ecri_nationalite` varchar(30) CHARACTER SET latin1 DEFAULT '',
  `liv_ecri_remarques` text CHARACTER SET latin1,
  `liv_ecri_created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `liv_ecri_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_ecri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_ecrivain` VALUES ('29','King','Tabita',NULL,'L''épouse',NULL,NULL);
INSERT INTO `liv_ecrivain` VALUES ('30','toto','pour faire 4','Fr','test date màj 4',NULL,'0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('31','King','Stephen','A','Prolifique',NULL,NULL);
INSERT INTO `liv_ecrivain` VALUES ('32','écrivain','1',NULL,NULL,NULL,NULL);
INSERT INTO `liv_ecrivain` VALUES ('33','écrivain','2',NULL,NULL,NULL,NULL);
INSERT INTO `liv_ecrivain` VALUES ('34','écrivain','5',NULL,NULL,NULL,NULL);
INSERT INTO `liv_ecrivain` VALUES ('35','écrivain','4',NULL,NULL,NULL,NULL);
INSERT INTO `liv_ecrivain` VALUES ('36','écrivain','3',NULL,NULL,NULL,NULL);
INSERT INTO `liv_ecrivain` VALUES ('37','écrivain','2',NULL,NULL,NULL,NULL);


DROP TABLE IF EXISTS `liv_editeur`;
CREATE TABLE `liv_editeur` (
  `liv_edit_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_edit_nom` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_edit_remarques` text CHARACTER SET latin1,
  `liv_edit_created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `liv_edit_updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`liv_edit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_editeur` VALUES ('15','Plon',NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_editeur` VALUES ('16','Grand Livre du Mois','Coûte plus cher que chez Amazon','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_editeur` VALUES ('17','Poche',NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_editeur` VALUES ('51','J''ai Lu',NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00');


DROP TABLE IF EXISTS `liv_livre`;
CREATE TABLE `liv_livre` (
  `livre_id` int(11) NOT NULL AUTO_INCREMENT,
  `livre_auteur_id` int(11) NOT NULL,
  `livre_theme_id` int(11) NOT NULL,
  `livre_editeur_id` int(11) NOT NULL,
  `livre_couverture_id` int(11) NOT NULL,
  `livre_titre` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `livre_anneeCopyright` int(11) DEFAULT NULL,
  `livre_date_achat` datetime DEFAULT '0000-00-00 00:00:00',
  `livre_prix_achat` decimal(10,2) DEFAULT NULL,
  `livre_nb_pages` int(11) DEFAULT NULL,
  `livre_remarques` text CHARACTER SET latin1,
  `livre_a_lire` tinyint(1) NOT NULL DEFAULT '1',
  `livre_vocabulaire` tinyint(1) NOT NULL DEFAULT '0',
  `livre_en_stock` tinyint(1) NOT NULL DEFAULT '1',
  `livre_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `livre_updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`livre_id`),
  KEY `idx_livre_theme_id` (`livre_theme_id`),
  KEY `FK_editeur_idx` (`livre_editeur_id`),
  KEY `FK_couverture_idx` (`livre_couverture_id`),
  CONSTRAINT `FK_theme` FOREIGN KEY (`livre_theme_id`) REFERENCES `liv_theme` (`liv_them_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_livre` VALUES ('5','17','1','15','2','Un autre livre','2014','0000-00-00 00:00:00','22.00','250',NULL,'1','1','1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('6','0','3','16','4','Test',NULL,NULL,NULL,NULL,NULL,'1','0','1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('7','0','3','16','2','y',NULL,'0000-00-00 00:00:00',NULL,'2147483647',NULL,'1','0','1','0000-00-00 00:00:00','0000-00-00 00:00:00');


DROP TABLE IF EXISTS `liv_theme`;
CREATE TABLE `liv_theme` (
  `liv_them_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_them_libelle` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_them_created_on` timestamp NULL DEFAULT NULL,
  `liv_them_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_them_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_theme` VALUES ('1','Fantastique','2015-05-13 00:00:00',NULL);
INSERT INTO `liv_theme` VALUES ('2','Educatif','2015-05-14 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_theme` VALUES ('3','Culinaire','2015-05-13 00:00:00','2015-05-13 00:00:00');
INSERT INTO `liv_theme` VALUES ('5','Science fiction','2015-05-13 00:00:00',NULL);
INSERT INTO `liv_theme` VALUES ('6','Policier','2015-05-13 00:00:00',NULL);
INSERT INTO `liv_theme` VALUES ('8','Suspense','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_theme` VALUES ('31','Frisson','0000-00-00 00:00:00','0000-00-00 00:00:00');


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `auth_key` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `password_hash` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `password_reset_token` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `email` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '10',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `user` VALUES ('1','sa','','','ezs824','','10','2015-05-29 18:46:58','0000-00-00 00:00:00');
