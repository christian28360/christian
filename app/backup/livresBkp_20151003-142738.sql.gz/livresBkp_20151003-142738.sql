--
-- livresBkp_20151003-142738.sql.gz


DROP TABLE IF EXISTS `liv_auteur`;
CREATE TABLE `liv_auteur` (
  `liv_aut_livre_id` int(11) NOT NULL,
  `liv_aut_ecri_id` int(11) NOT NULL,
  PRIMARY KEY (`liv_aut_livre_id`,`liv_aut_ecri_id`),
  KEY `FK_liv_ecri_id` (`liv_aut_ecri_id`),
  CONSTRAINT `FK_livre_id` FOREIGN KEY (`liv_aut_livre_id`) REFERENCES `liv_livre` (`livre_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_liv_ecri_id` FOREIGN KEY (`liv_aut_ecri_id`) REFERENCES `liv_ecrivain` (`liv_ecri_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;


DROP TABLE IF EXISTS `liv_couverture`;
CREATE TABLE `liv_couverture` (
  `liv_couv_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_couv_libelle` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_couv_created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `liv_couv_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_couv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_couverture` VALUES ('5','Cartonnée','2015-10-03 14:23:58','2015-10-03 14:23:58');
INSERT INTO `liv_couverture` VALUES ('6','Souple','2015-10-03 14:25:35','2015-10-03 14:25:35');
INSERT INTO `liv_couverture` VALUES ('7','Molle','2015-10-03 14:25:45','2015-10-03 14:25:45');
INSERT INTO `liv_couverture` VALUES ('8','Cartonnée souple','2015-10-03 14:26:18','2015-10-03 14:26:18');
INSERT INTO `liv_couverture` VALUES ('9','Cartonnée rigide','2015-10-03 14:26:33','2015-10-03 14:26:33');
INSERT INTO `liv_couverture` VALUES ('10','Cartonnée renforcée','2015-10-03 14:26:43','2015-10-03 14:26:43');
INSERT INTO `liv_couverture` VALUES ('11','Cartonnée recouverte','2015-10-03 14:26:58','2015-10-03 14:26:58');
INSERT INTO `liv_couverture` VALUES ('12','Souple recouverte','2015-10-03 14:27:17','2015-10-03 14:27:17');


DROP TABLE IF EXISTS `liv_ecrivain`;
CREATE TABLE `liv_ecrivain` (
  `liv_ecri_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_ecri_nom` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_ecri_prenom` varchar(100) CHARACTER SET latin1 DEFAULT '',
  `liv_ecri_nationalite` varchar(30) CHARACTER SET latin1 DEFAULT '',
  `liv_ecri_remarques` text CHARACTER SET latin1,
  `liv_ecri_created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `liv_ecri_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_ecri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=404 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_ecrivain` VALUES ('282','Nom','Pr�nom','Nationalit�','Remarques','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('283','Albouy','Vincent',NULL,NULL,'0000-00-00 00:00:00','2015-10-03 13:35:48');
INSERT INTO `liv_ecrivain` VALUES ('284','All�gre','Claude','Fran�aise','Scientifique, vulgarisateur','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('285','Arnothy','Christine','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('286','Aucun','Auteur','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('287','Bachmann','Richard','Am�ricaine','Nom de ville de Stephen King','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('288','Bailly','Othilie','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('289','Bazin','Herv�','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('290','Bensa�d','Norbert','Fran�aise','M�decin et journaliste','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('291','Bidault','H�l�ne','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('292','Blatrier','Jean Michel','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('293','Bleu','Fran�oise','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('294','Bodard','Lucien','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('295','Boissard','Janine','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('296','Bourin','Jeanne','','Epouse de l''�diteur Fran�ois Bourin ?','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('297','Bouvard','Philippe','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('298','Brauner','Alfred','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('299','Bret','Mich�le','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('300','Brown','Dan','Am�ricaine','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('301','Calabre','Isabelle','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('302','Capote','Truman','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('303','Cardinal','Marie','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('304','Cartland','Barbara','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('305','Chatelain','Emile','','Membre de l''institut','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('306','Chevalier','Jean','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('307','Christie','Agatha','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('308','Clerc','Roger','','N� en 1908','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('309','Cleveland','Harland','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('310','Colignon','Jean-Pierre','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('311','Coluche','Michel','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('312','Conan Doyle','Arthur','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('313','Coppens','Yves','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('314','Courcel','Pierre','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('315','Cousture','Arlette','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('316','Dard','Fr�d�ric','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('317','Dard','Patrice','Fran�aise','Le fils de Fr�d�ric','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('318','De Gans','Guy','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('319','de Laroche','Robert','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('320','Delavier','Fr�d�ric','Fran�aise','Etudes de morphologie','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('321','Demazi�re','Raymonde','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('322','Devos','Raymond','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('323','Dormann','Genevi�ve','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('324','Dorseuil','Alain','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('325','Doutreland','Pierre-Marie','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('326','Dramert','Val�rie','','Dr v�t�rinaire','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('327','du Maurier','Daphn�','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('328','Dubois','Philippe J.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('329','Duquesne','Jacques','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('330','Duquet','Marc','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('331','Fernandez','Dominique','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('332','Fierro','Alfred','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('333','Filliozat','Anne-Marie','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('334','Flaubert','Gustave','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('335','Forti','Augusto','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('336','Fosnes Hansen','Erik','Norv�gienne','N� � New-York','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('337','Gabriel','A.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('338','Gauquelin','Michel et Fran�oise','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('339','Gheerbrant','Alain','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('340','Giono','Jean','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('341','Glaister','Lesley','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('342','Golibert','Pierre','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('343','Gouriot','Jean-Marie','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('344','Graham','Patrick','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('345','Grisham','John','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('346','Guasch','G�rard','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('347','Guedj','Denis','Fran�aise','Math�maticien','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('348','H�brard','Fr�d�rique','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('349','Herbert','Franck','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('350','Higgins Clark','Mary','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('351','Hourquin','Didier','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('352','Hugo','Victor','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('353','Ionesco','Eug�ne','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('354','James','Phyllis Dorothy','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('355','Kermel','Marie','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('356','King','Stephen','Am�ricaine','Pseudonyme, �crit aussi sous son nom : Richard Bachman','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('357','King','Tabitha','Am�ricaine','Epouse de Stephen King','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('358','King','Laurie','Am�ricaine','La fille ?','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('359','Krakowiak','Sacha','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('360','Krisa','Bohdan','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('361','La Fontaine','Jean','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('362','Lacave','Mireille','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('363','Larkin','Patrick','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('364','Lef�bre','Fran�oise','Fran�aise','N�e � Paris','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('365','Ludlum','Robert','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('366','Margueritte','Yves','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('367','McCullough','Colleen','Am�ricaine','D''origine Irlandaise, n�e en Australie, �migr�e aux USA','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('368','Montagn�','Guy','Fran�aise','Humoriste','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('369','Nourissier','Fan�ois','Fran�aise','de l''acad�mie Goncourt','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('370','Patterson','James','Am�ricaine','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('371','Payri','Odile','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('372','Phythian','B.A.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('373','Ramiandrisoa','Joana','Malgache (1953)','Il arrive en France en 1961, abandonne la psychanalyse en 84 pour se consacrer � l''�ducation','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('374','Richaudeau','Fran�ois','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('375','Robine','Marc','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('376','Robotham','Michael','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('377','Rougelet','Patrick','Fran�aise','Ancien membre des R.G.','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('378','Sabatier','Robert','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('379','Salavert','Marie-H�l�ne','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('380','Salom�','Jacques','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('381','Samson','Isabelle et R�my','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('382','Savage','Tom','Am�ricaine','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('383','Schmidt','Jo�l','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('384','S�chan','Thierry','Fran�aise','Fr�re du chanteur Renaud (S�chan)','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('385','Selz','Reiner K.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('386','Shakespeare','','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('387','Shelley','Mary','Am�ricaine ou anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('388','Sim','','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('389','Simiot','Bernard','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('390','Stanislav','Frank','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('391','Straub','Peter','Am�ricaine','A �crit conjointement avec Stephen King.','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('392','Su�tone','','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('393','Tessier','Colette','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('394','Thibaux','Jean-Michel','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('395','Thierry','Jean-Pierre','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('396','Travis','Robert','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('397','Universalis','Encyclopaedia','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('398','Van Vogt','A.E.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('399','Vernes','Jules','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('400','Vincent','J.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('401','Volkmann','Jean-Charles','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('402','Weisman','Alan','Anglais','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('403','Young','Robyn','','','0000-00-00 00:00:00','0000-00-00 00:00:00');


DROP TABLE IF EXISTS `liv_editeur`;
CREATE TABLE `liv_editeur` (
  `liv_edit_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_edit_nom` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_edit_remarques` text CHARACTER SET latin1,
  `liv_edit_created_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `liv_edit_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`liv_edit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_editeur` VALUES ('194','','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('195','Albin Michel','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('196','Anne Carri�re','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('197','Belfond','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('198','Biblioth�que du CEPL','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('199','Cariscript','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('200','Centre d''�tude et de promotion de la lecture','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('201','Chancellor press','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('202','Colleen McCullough','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('203','Dargaud','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('204','De Vecchi','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('205','Dunod','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('206','Editions de La Table Ronde','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('207','Editions de l''Archipel','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('208','Editions du Rocher','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('209','Editions du Seuil','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('210','Editions Famot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('211','Editions Fayard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('212','Editions Fixot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('213','Editions gammaprim','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('214','Editions Gisserot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('215','Editions Grasset','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('216','Editions Payot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('217','Editions Presse cit�','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('218','Editions universitaires','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('219','Encyclopaedia Universalis','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('220','Flammarion','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('221','Fleuve noir','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('222','Fran�ois Bourin','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('223','Gallimard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('224','Garnier fr�res','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('225','Gen�ve','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('226','Grasset','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('227','Gr�nd','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('228','Guild Publishing London','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('229','Hachette','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('230','Hachette litt�rature','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('231','Hatier','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('232','Inconnu','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('233','J''ai lu','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('234','Jean de Bonnot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('235','Laffont Robert','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('236','Larousse-Bordas','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('237','Latt�s','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('238','Le cherche midi','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('239','Le Club','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('240','Le courrier du livre','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('241','Le foyer de Cachan','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('242','Le Grand Livre du Mois','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('243','Le Livre de poche','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('244','Librairie Arth�me Fayard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('245','Librio','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('246','Longman','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('247','Magnard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('248','Maisonneuve et Larose','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('249','Mazarine','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('250','Michel Laffont','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('251','Micro Application','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('252','Oxford University Press','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('253','Parigramme','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('254','Phythian B.A.','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('255','Plon','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('256','Presses Pocket','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('257','Reader''s Digest','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('258','Rustica �ditions','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('259','Selz �ditions','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('260','Seuil','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('261','Tr�visse','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('262','Vigot','',NULL,NULL);


DROP TABLE IF EXISTS `liv_livre`;
CREATE TABLE `liv_livre` (
  `livre_id` int(11) NOT NULL AUTO_INCREMENT,
  `livre_auteur_id` int(11) NOT NULL,
  `livre_theme_id` int(11) NOT NULL,
  `livre_editeur_id` int(11) NOT NULL,
  `livre_couverture_id` int(11) NOT NULL,
  `livre_titre` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `livre_anneeCopyright` int(11) DEFAULT NULL,
  `livre_date_achat` datetime DEFAULT '0000-00-00 00:00:00',
  `livre_prix_achat` decimal(10,2) DEFAULT NULL,
  `livre_nb_pages` int(11) DEFAULT NULL,
  `livre_remarques` text CHARACTER SET latin1,
  `livre_a_lire` tinyint(1) NOT NULL DEFAULT '1',
  `livre_vocabulaire` tinyint(1) NOT NULL DEFAULT '0',
  `livre_en_stock` tinyint(1) NOT NULL DEFAULT '1',
  `livre_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `livre_updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`livre_id`),
  KEY `idx_livre_theme_id` (`livre_theme_id`),
  KEY `FK_editeur_idx` (`livre_editeur_id`),
  KEY `FK_couverture_idx` (`livre_couverture_id`),
  CONSTRAINT `FK_theme` FOREIGN KEY (`livre_theme_id`) REFERENCES `liv_theme` (`liv_them_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;


DROP TABLE IF EXISTS `liv_theme`;
CREATE TABLE `liv_theme` (
  `liv_them_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_them_libelle` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `liv_them_created_on` timestamp NULL DEFAULT NULL,
  `liv_them_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_them_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_theme` VALUES ('57','Sujet','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_theme` VALUES ('58','Affaires',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('59','Bibliographie',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('60','Dictionnaire',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('61','Documentaire',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('62','Encyclopédie',NULL,'2015-10-03 14:12:09');
INSERT INTO `liv_theme` VALUES ('63','Essais - études',NULL,'2015-10-03 14:15:35');
INSERT INTO `liv_theme` VALUES ('64','Fantastique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('65','Guide pratique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('66','Histoire',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('67','Humour',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('68','Inconnu',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('69','Informatique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('70','Poésie',NULL,'2015-10-03 14:16:00');
INSERT INTO `liv_theme` VALUES ('71','Policier',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('72','Psychologie',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('73','Roman',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('74','Santé',NULL,'2015-10-03 14:15:45');
INSERT INTO `liv_theme` VALUES ('75','Science',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('76','Science-fiction',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('77','Sentimental',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('78','Suspence',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('79','Technique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('80','Terroir',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('81','Théatre',NULL,'2015-10-03 14:16:10');


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `auth_key` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `password_hash` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `password_reset_token` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `email` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '10',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `user` VALUES ('1','sa','','','ezs824','','10','2015-05-29 18:46:58','0000-00-00 00:00:00');
