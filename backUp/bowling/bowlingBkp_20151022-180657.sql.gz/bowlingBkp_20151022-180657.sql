--
-- bowlingBkp_20151022-180657.sql.gz


DROP TABLE IF EXISTS `bowl_bowling`;
CREATE TABLE `bowl_bowling` (
  `bowl_bowling_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_bowling_nom` varchar(100) COLLATE latin1_general_cs NOT NULL,
  `bowl_bowling_commentaire` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_no` varchar(10) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_rue` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_alias` varchar(100) COLLATE latin1_general_cs DEFAULT NULL COMMENT 'ex. Bowling de Rambouillet',
  `bowl_bowling_adr_adr1` varchar(100) COLLATE latin1_general_cs DEFAULT NULL COMMENT 'compl�ment adresse 1',
  `bowl_bowling_adr_adr2` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_adr3` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_cp` mediumint(6) DEFAULT NULL,
  `bowl_bowling_adr_ville` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_adr_pays` varchar(100) COLLATE latin1_general_cs DEFAULT 'France',
  `bowl_bowling_tel_1` varchar(15) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_tel_2` varchar(15) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_mail` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_web` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_bowling_created_on` datetime DEFAULT NULL,
  `bowl_bowling_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_bowling_id`),
  KEY `bowl_bowling_nom` (`bowl_bowling_nom`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `bowl_bowling` VALUES ('1','Chartres','Va bientôt fermer ?','28000',NULL,NULL,NULL,NULL,NULL,'127','Chartres','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','www.bowling.chartres.com\r\n',NULL,'2015-10-17 09:13:10');
INSERT INTO `bowl_bowling` VALUES ('2','Barjouville','Va déménager à l''Odyssée ?','28600','Pierre Missigaut',NULL,'Z.A. La Torche',NULL,NULL,'127','Barjouville','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','wwww.xbowl.com',NULL,'2015-10-18 15:01:54');
INSERT INTO `bowl_bowling` VALUES ('3','Saran',NULL,'45200',NULL,NULL,NULL,NULL,NULL,'127','Saran','France','02 37 ...','06 84 ...','bowlingchartres@orange.fr','www.bowling.chartres.com',NULL,'2015-10-18 15:01:29');
INSERT INTO `bowl_bowling` VALUES ('4','Olivet','C''est le bowling d''Orléans',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'France',NULL,NULL,NULL,NULL,'2015-10-17 09:11:22','2015-10-18 15:00:26');
INSERT INTO `bowl_bowling` VALUES ('5','Orléans','Situé à Olivet',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'France',NULL,NULL,NULL,NULL,'2015-10-18 15:01:12','2015-10-18 15:01:12');


DROP TABLE IF EXISTS `bowl_evenement`;
CREATE TABLE `bowl_evenement` (
  `bowl_evt_id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `bowl_evt_code` varchar(10) COLLATE latin1_general_cs NOT NULL,
  `bowl_evt_bowl_id` int(11) DEFAULT NULL,
  `bowl_evt_typeJeu_id` int(11) DEFAULT NULL,
  `bowl_evt_formation_id` int(11) DEFAULT NULL,
  `bowl_evt_libelle` varchar(50) COLLATE latin1_general_cs DEFAULT NULL,
  `bowl_evt_created_on` datetime DEFAULT NULL,
  `bowl_evt_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_evt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `bowl_evenement` VALUES ('1','L','2','3',NULL,'Jeudi 20h','2015-10-18 17:57:03','2015-10-20 11:43:03');
INSERT INTO `bowl_evenement` VALUES ('2','E','3','2','6','Entrainement','2015-10-18 17:57:41','2015-10-21 13:40:41');
INSERT INTO `bowl_evenement` VALUES ('3','LBM18','2','3','8','Mardi 18h','2015-10-18 17:58:14','2015-10-20 11:58:02');
INSERT INTO `bowl_evenement` VALUES ('4','LBM20','2','3','7','Mardi 20h','2015-10-18 17:58:47','2015-10-20 11:58:28');
INSERT INTO `bowl_evenement` VALUES ('5','E2','4','2',NULL,'entrainement 2','2015-10-18 17:59:46','2015-10-21 18:15:38');
INSERT INTO `bowl_evenement` VALUES ('6','e',NULL,'7',NULL,'ee','2015-10-18 17:59:57','2015-10-19 16:27:23');
INSERT INTO `bowl_evenement` VALUES ('7','jjjjjjj',NULL,NULL,NULL,'jj','2015-10-19 16:27:42','2015-10-19 16:27:42');
INSERT INTO `bowl_evenement` VALUES ('8','T','2','4','6','Tournoi','2015-10-22 15:22:02','2015-10-22 15:22:02');


DROP TABLE IF EXISTS `bowl_formation`;
CREATE TABLE `bowl_formation` (
  `bowl_form_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_form_code` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_form_libelle` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_form_created_on` datetime DEFAULT NULL,
  `bowl_form_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_formation` VALUES ('1','3MH','Triplette mixte handicap','2015-10-18 18:07:08','2015-10-18 18:07:08');
INSERT INTO `bowl_formation` VALUES ('2','5S','Equipe de 5 scratch','2015-10-18 18:07:42','2015-10-18 18:07:42');
INSERT INTO `bowl_formation` VALUES ('3','1S','Individuel scratch','2015-10-18 18:08:11','2015-10-18 18:08:11');
INSERT INTO `bowl_formation` VALUES ('4','1Chon','Individuel catégorie honneur','2015-10-18 18:09:03','2015-10-18 18:09:03');
INSERT INTO `bowl_formation` VALUES ('5','2MH','Doublette mixte handicap','2015-10-18 18:09:59','2015-10-18 18:11:37');
INSERT INTO `bowl_formation` VALUES ('6','1','Individuel','2015-10-20 11:53:02','2015-10-20 11:53:02');
INSERT INTO `bowl_formation` VALUES ('7','2H','Doublette handicap','2015-10-20 11:57:24','2015-10-20 11:57:24');
INSERT INTO `bowl_formation` VALUES ('8','3H','Triplette handicap','2015-10-20 11:57:43','2015-10-20 11:57:43');


DROP TABLE IF EXISTS `bowl_periode`;
CREATE TABLE `bowl_periode` (
  `bowl_periode_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_periode_dt_deb` datetime DEFAULT NULL,
  `bowl_periode_dt_fin` datetime DEFAULT NULL,
  `bowl_periode_libelle` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_periode_is_active` bit(1) DEFAULT NULL,
  `bowl_periode_created_on` datetime DEFAULT NULL,
  `bowl_periode_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_periode_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_periode` VALUES ('3','2015-09-01 00:00:00','2016-08-31 00:00:00','test manuel','1',NULL,NULL);
INSERT INTO `bowl_periode` VALUES ('6','2014-08-31 00:00:00','2015-09-01 00:00:00',NULL,NULL,'2015-10-18 18:30:17','2015-10-18 18:30:17');
INSERT INTO `bowl_periode` VALUES ('7','2016-01-01 00:00:00','2016-01-01 00:00:00','a virer',NULL,'2015-10-18 18:33:53','2015-10-18 18:33:53');


DROP TABLE IF EXISTS `bowl_score`;
CREATE TABLE `bowl_score` (
  `bowl_score_id` mediumint(3) NOT NULL AUTO_INCREMENT,
  `bowl_score_date` datetime DEFAULT NULL,
  `bowl_score_evt_id` tinyint(1) NOT NULL,
  `bowl_score_score` smallint(6) NOT NULL,
  `bowl_score_strike` tinyint(1) DEFAULT NULL,
  `bowl_score_spare` tinyint(1) DEFAULT NULL,
  `bowl_score_split` tinyint(1) DEFAULT NULL,
  `bowl_score_handicap` tinyint(1) DEFAULT NULL,
  `bowl_score_gagnee` bit(1) DEFAULT NULL,
  `bowl_score_created_on` datetime DEFAULT NULL,
  `bowl_score_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`bowl_score_id`),
  KEY `bow_score_bow_score_evenement_idx` (`bowl_score_evt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `bowl_score` VALUES ('1','2015-10-20 00:00:00','2','185','5','4','2','45','0',NULL,'2015-10-22 15:10:14');
INSERT INTO `bowl_score` VALUES ('2','2014-06-05 00:00:00','3','155',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `bowl_score` VALUES ('3','2015-10-03 00:00:00','5','222','5','4','0',NULL,'1','2015-10-21 18:13:57','2015-10-22 15:04:08');
INSERT INTO `bowl_score` VALUES ('4','2015-10-22 00:00:00','6','120',NULL,NULL,NULL,NULL,'1','2015-10-22 11:08:24','2015-10-22 14:58:42');
INSERT INTO `bowl_score` VALUES ('5','2015-10-12 00:00:00','6','198',NULL,NULL,NULL,NULL,'1','2015-10-22 11:08:30','2015-10-22 15:12:42');
INSERT INTO `bowl_score` VALUES ('6','2015-01-12 00:00:00','2','10',NULL,NULL,NULL,NULL,'0','2015-10-22 11:08:51','2015-10-22 15:11:30');
INSERT INTO `bowl_score` VALUES ('7','2015-06-02 14:11:32','3','325',NULL,NULL,NULL,NULL,NULL,'2015-10-22 13:47:31','2015-10-22 13:47:31');
INSERT INTO `bowl_score` VALUES ('8','2015-10-01 00:00:00','2','120',NULL,NULL,'5',NULL,'0','2015-10-22 14:20:24','2015-10-22 15:12:00');
INSERT INTO `bowl_score` VALUES ('9','2015-01-01 00:00:00','2','0',NULL,NULL,NULL,NULL,NULL,'2015-10-22 14:29:41','2015-10-22 14:29:41');
INSERT INTO `bowl_score` VALUES ('10','2015-01-01 00:00:00','2','120',NULL,NULL,NULL,NULL,NULL,'2015-10-22 14:42:56','2015-10-22 14:42:56');
INSERT INTO `bowl_score` VALUES ('11','2015-01-01 00:00:00','2','5','2','2','3',NULL,NULL,'2015-10-22 14:50:26','2015-10-22 14:50:26');
INSERT INTO `bowl_score` VALUES ('12','2015-10-12 00:00:00','1','175','2','2','2',NULL,'0','2015-10-22 15:05:57','2015-10-22 15:10:31');
INSERT INTO `bowl_score` VALUES ('13','2014-02-28 00:00:00','2','123',NULL,NULL,NULL,NULL,'0','2015-10-22 15:20:45','2015-10-22 15:20:45');
INSERT INTO `bowl_score` VALUES ('14','2015-10-25 00:00:00','8','188',NULL,NULL,NULL,NULL,'0','2015-10-22 15:22:39','2015-10-22 15:22:39');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');


DROP TABLE IF EXISTS `bowl_type_jeu`;
CREATE TABLE `bowl_type_jeu` (
  `bowl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `bowl_type_type` char(1) COLLATE latin1_general_ci NOT NULL,
  `bowl_type_libelle` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `bowl_type_created_on` datetime DEFAULT NULL,
  `bowl_type_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`bowl_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `bowl_type_jeu` VALUES ('1','A','les autres',NULL,'2015-10-19 16:01:03');
INSERT INTO `bowl_type_jeu` VALUES ('2','E','Entrainement',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('3','L','Ligue','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `bowl_type_jeu` VALUES ('4','T','Tournoi',NULL,NULL);
INSERT INTO `bowl_type_jeu` VALUES ('5','r','rrr','2015-10-17 09:24:38','2015-10-19 11:31:02');
INSERT INTO `bowl_type_jeu` VALUES ('6','z','zf','2015-10-17 09:25:05','2015-10-18 15:14:03');
INSERT INTO `bowl_type_jeu` VALUES ('7','C','Championnat','2015-10-19 11:30:24','2015-10-19 11:30:24');
