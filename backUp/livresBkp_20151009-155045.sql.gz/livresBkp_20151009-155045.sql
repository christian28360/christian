--
-- livresBkp_20151009-155045.sql.gz


DROP TABLE IF EXISTS `liv_auteur`;
CREATE TABLE `liv_auteur` (
  `liv_aut_livre_id` int(11) NOT NULL,
  `liv_aut_ecri_id` int(11) NOT NULL,
  PRIMARY KEY (`liv_aut_livre_id`,`liv_aut_ecri_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_auteur` VALUES ('1','377');
INSERT INTO `liv_auteur` VALUES ('2','389');
INSERT INTO `liv_auteur` VALUES ('3','356');
INSERT INTO `liv_auteur` VALUES ('4','312');
INSERT INTO `liv_auteur` VALUES ('5','387');
INSERT INTO `liv_auteur` VALUES ('6','289');
INSERT INTO `liv_auteur` VALUES ('7','388');
INSERT INTO `liv_auteur` VALUES ('8','340');
INSERT INTO `liv_auteur` VALUES ('9','334');
INSERT INTO `liv_auteur` VALUES ('10','285');
INSERT INTO `liv_auteur` VALUES ('11','294');
INSERT INTO `liv_auteur` VALUES ('12','303');
INSERT INTO `liv_auteur` VALUES ('13','310');
INSERT INTO `liv_auteur` VALUES ('14','356');
INSERT INTO `liv_auteur` VALUES ('15','356');
INSERT INTO `liv_auteur` VALUES ('16','356');
INSERT INTO `liv_auteur` VALUES ('17','356');
INSERT INTO `liv_auteur` VALUES ('18','287');
INSERT INTO `liv_auteur` VALUES ('19','350');
INSERT INTO `liv_auteur` VALUES ('20','356');
INSERT INTO `liv_auteur` VALUES ('21','356');
INSERT INTO `liv_auteur` VALUES ('22','356');
INSERT INTO `liv_auteur` VALUES ('23','344');
INSERT INTO `liv_auteur` VALUES ('24','341');
INSERT INTO `liv_auteur` VALUES ('25','367');
INSERT INTO `liv_auteur` VALUES ('26','359');
INSERT INTO `liv_auteur` VALUES ('28','355');
INSERT INTO `liv_auteur` VALUES ('28','379');
INSERT INTO `liv_auteur` VALUES ('29','315');
INSERT INTO `liv_auteur` VALUES ('30','319');
INSERT INTO `liv_auteur` VALUES ('31','347');
INSERT INTO `liv_auteur` VALUES ('32','331');
INSERT INTO `liv_auteur` VALUES ('33','317');
INSERT INTO `liv_auteur` VALUES ('34','317');
INSERT INTO `liv_auteur` VALUES ('35','317');
INSERT INTO `liv_auteur` VALUES ('36','317');
INSERT INTO `liv_auteur` VALUES ('37','284');
INSERT INTO `liv_auteur` VALUES ('38','351');
INSERT INTO `liv_auteur` VALUES ('39','363');
INSERT INTO `liv_auteur` VALUES ('39','365');
INSERT INTO `liv_auteur` VALUES ('41','394');
INSERT INTO `liv_auteur` VALUES ('42','400');
INSERT INTO `liv_auteur` VALUES ('43','402');
INSERT INTO `liv_auteur` VALUES ('44','356');
INSERT INTO `liv_auteur` VALUES ('45','314');
INSERT INTO `liv_auteur` VALUES ('46','396');
INSERT INTO `liv_auteur` VALUES ('47','353');
INSERT INTO `liv_auteur` VALUES ('49','375');
INSERT INTO `liv_auteur` VALUES ('49','384');
INSERT INTO `liv_auteur` VALUES ('50','356');
INSERT INTO `liv_auteur` VALUES ('51','289');
INSERT INTO `liv_auteur` VALUES ('52','364');
INSERT INTO `liv_auteur` VALUES ('53','356');
INSERT INTO `liv_auteur` VALUES ('54','356');
INSERT INTO `liv_auteur` VALUES ('55','356');
INSERT INTO `liv_auteur` VALUES ('56','356');
INSERT INTO `liv_auteur` VALUES ('57','356');
INSERT INTO `liv_auteur` VALUES ('58','356');
INSERT INTO `liv_auteur` VALUES ('59','356');
INSERT INTO `liv_auteur` VALUES ('60','356');
INSERT INTO `liv_auteur` VALUES ('61','356');
INSERT INTO `liv_auteur` VALUES ('62','356');
INSERT INTO `liv_auteur` VALUES ('63','356');
INSERT INTO `liv_auteur` VALUES ('64','332');
INSERT INTO `liv_auteur` VALUES ('65','349');
INSERT INTO `liv_auteur` VALUES ('66','349');
INSERT INTO `liv_auteur` VALUES ('67','349');
INSERT INTO `liv_auteur` VALUES ('68','349');
INSERT INTO `liv_auteur` VALUES ('69','357');
INSERT INTO `liv_auteur` VALUES ('70','376');
INSERT INTO `liv_auteur` VALUES ('71','356');
INSERT INTO `liv_auteur` VALUES ('72','356');
INSERT INTO `liv_auteur` VALUES ('73','356');
INSERT INTO `liv_auteur` VALUES ('74','356');
INSERT INTO `liv_auteur` VALUES ('75','356');
INSERT INTO `liv_auteur` VALUES ('76','356');
INSERT INTO `liv_auteur` VALUES ('77','356');
INSERT INTO `liv_auteur` VALUES ('78','308');
INSERT INTO `liv_auteur` VALUES ('79','292');
INSERT INTO `liv_auteur` VALUES ('80','283');
INSERT INTO `liv_auteur` VALUES ('82','328');
INSERT INTO `liv_auteur` VALUES ('82','330');
INSERT INTO `liv_auteur` VALUES ('83','356');
INSERT INTO `liv_auteur` VALUES ('84','356');
INSERT INTO `liv_auteur` VALUES ('85','287');
INSERT INTO `liv_auteur` VALUES ('86','356');
INSERT INTO `liv_auteur` VALUES ('87','356');
INSERT INTO `liv_auteur` VALUES ('89','309');
INSERT INTO `liv_auteur` VALUES ('89','335');
INSERT INTO `liv_auteur` VALUES ('90','324');
INSERT INTO `liv_auteur` VALUES ('91','301');
INSERT INTO `liv_auteur` VALUES ('92','349');
INSERT INTO `liv_auteur` VALUES ('93','290');
INSERT INTO `liv_auteur` VALUES ('94','320');
INSERT INTO `liv_auteur` VALUES ('95','356');
INSERT INTO `liv_auteur` VALUES ('96','308');
INSERT INTO `liv_auteur` VALUES ('97','398');
INSERT INTO `liv_auteur` VALUES ('98','371');
INSERT INTO `liv_auteur` VALUES ('99','350');
INSERT INTO `liv_auteur` VALUES ('100','358');
INSERT INTO `liv_auteur` VALUES ('101','380');
INSERT INTO `liv_auteur` VALUES ('102','315');
INSERT INTO `liv_auteur` VALUES ('103','323');
INSERT INTO `liv_auteur` VALUES ('105','333');
INSERT INTO `liv_auteur` VALUES ('105','346');
INSERT INTO `liv_auteur` VALUES ('106','287');
INSERT INTO `liv_auteur` VALUES ('107','356');
INSERT INTO `liv_auteur` VALUES ('108','356');
INSERT INTO `liv_auteur` VALUES ('109','356');
INSERT INTO `liv_auteur` VALUES ('110','356');
INSERT INTO `liv_auteur` VALUES ('111','356');
INSERT INTO `liv_auteur` VALUES ('112','356');
INSERT INTO `liv_auteur` VALUES ('113','356');
INSERT INTO `liv_auteur` VALUES ('114','382');
INSERT INTO `liv_auteur` VALUES ('115','366');
INSERT INTO `liv_auteur` VALUES ('116','395');
INSERT INTO `liv_auteur` VALUES ('117','373');
INSERT INTO `liv_auteur` VALUES ('118','401');
INSERT INTO `liv_auteur` VALUES ('119','393');
INSERT INTO `liv_auteur` VALUES ('120','316');
INSERT INTO `liv_auteur` VALUES ('121','399');
INSERT INTO `liv_auteur` VALUES ('122','342');
INSERT INTO `liv_auteur` VALUES ('123','356');
INSERT INTO `liv_auteur` VALUES ('123','391');
INSERT INTO `liv_auteur` VALUES ('124','356');
INSERT INTO `liv_auteur` VALUES ('124','391');
INSERT INTO `liv_auteur` VALUES ('125','345');
INSERT INTO `liv_auteur` VALUES ('126','356');
INSERT INTO `liv_auteur` VALUES ('126','391');
INSERT INTO `liv_auteur` VALUES ('128','356');
INSERT INTO `liv_auteur` VALUES ('129','370');
INSERT INTO `liv_auteur` VALUES ('130','311');
INSERT INTO `liv_auteur` VALUES ('131','368');
INSERT INTO `liv_auteur` VALUES ('132','403');
INSERT INTO `liv_auteur` VALUES ('133','313');
INSERT INTO `liv_auteur` VALUES ('134','317');
INSERT INTO `liv_auteur` VALUES ('135','343');
INSERT INTO `liv_auteur` VALUES ('136','322');
INSERT INTO `liv_auteur` VALUES ('137','326');
INSERT INTO `liv_auteur` VALUES ('138','327');
INSERT INTO `liv_auteur` VALUES ('139','356');
INSERT INTO `liv_auteur` VALUES ('140','291');
INSERT INTO `liv_auteur` VALUES ('140','298');
INSERT INTO `liv_auteur` VALUES ('140','299');
INSERT INTO `liv_auteur` VALUES ('143','381');
INSERT INTO `liv_auteur` VALUES ('144','318');
INSERT INTO `liv_auteur` VALUES ('145','321');
INSERT INTO `liv_auteur` VALUES ('146','302');
INSERT INTO `liv_auteur` VALUES ('147','340');
INSERT INTO `liv_auteur` VALUES ('148','340');
INSERT INTO `liv_auteur` VALUES ('149','340');
INSERT INTO `liv_auteur` VALUES ('150','340');
INSERT INTO `liv_auteur` VALUES ('151','305');
INSERT INTO `liv_auteur` VALUES ('152','337');
INSERT INTO `liv_auteur` VALUES ('153','306');
INSERT INTO `liv_auteur` VALUES ('153','339');
INSERT INTO `liv_auteur` VALUES ('155','383');
INSERT INTO `liv_auteur` VALUES ('156','360');
INSERT INTO `liv_auteur` VALUES ('157','354');
INSERT INTO `liv_auteur` VALUES ('158','293');
INSERT INTO `liv_auteur` VALUES ('158','385');
INSERT INTO `liv_auteur` VALUES ('160','397');
INSERT INTO `liv_auteur` VALUES ('161','397');
INSERT INTO `liv_auteur` VALUES ('162','352');
INSERT INTO `liv_auteur` VALUES ('163','361');
INSERT INTO `liv_auteur` VALUES ('164','352');
INSERT INTO `liv_auteur` VALUES ('165','386');
INSERT INTO `liv_auteur` VALUES ('166','392');
INSERT INTO `liv_auteur` VALUES ('167','286');
INSERT INTO `liv_auteur` VALUES ('168','378');
INSERT INTO `liv_auteur` VALUES ('169','338');
INSERT INTO `liv_auteur` VALUES ('169','374');
INSERT INTO `liv_auteur` VALUES ('170','338');
INSERT INTO `liv_auteur` VALUES ('170','374');
INSERT INTO `liv_auteur` VALUES ('173','288');
INSERT INTO `liv_auteur` VALUES ('174','325');
INSERT INTO `liv_auteur` VALUES ('175','362');
INSERT INTO `liv_auteur` VALUES ('176','296');
INSERT INTO `liv_auteur` VALUES ('177','329');
INSERT INTO `liv_auteur` VALUES ('178','369');
INSERT INTO `liv_auteur` VALUES ('179','286');
INSERT INTO `liv_auteur` VALUES ('180','295');
INSERT INTO `liv_auteur` VALUES ('181','297');
INSERT INTO `liv_auteur` VALUES ('182','390');
INSERT INTO `liv_auteur` VALUES ('183','307');
INSERT INTO `liv_auteur` VALUES ('184','307');
INSERT INTO `liv_auteur` VALUES ('185','307');
INSERT INTO `liv_auteur` VALUES ('186','307');
INSERT INTO `liv_auteur` VALUES ('187','286');
INSERT INTO `liv_auteur` VALUES ('188','286');
INSERT INTO `liv_auteur` VALUES ('189','372');
INSERT INTO `liv_auteur` VALUES ('190','336');
INSERT INTO `liv_auteur` VALUES ('191','304');
INSERT INTO `liv_auteur` VALUES ('192','304');
INSERT INTO `liv_auteur` VALUES ('193','348');


DROP TABLE IF EXISTS `liv_couverture`;
CREATE TABLE `liv_couverture` (
  `liv_couv_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_couv_libelle` varchar(100) COLLATE latin1_general_cs NOT NULL DEFAULT '',
  `liv_couv_created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `liv_couv_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_couv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_couverture` VALUES ('5','Cartonnée','2015-10-03 14:23:58','2015-10-04 14:07:14');
INSERT INTO `liv_couverture` VALUES ('6','Souple','2015-10-03 14:25:35','2015-10-03 14:25:35');
INSERT INTO `liv_couverture` VALUES ('7','Molle','2015-10-03 14:25:45','2015-10-03 14:25:45');
INSERT INTO `liv_couverture` VALUES ('8','Cartonnée souple','2015-10-03 14:26:18','2015-10-04 14:08:50');
INSERT INTO `liv_couverture` VALUES ('9','Cartonnée rigide','2015-10-03 14:26:33','2015-10-04 14:08:37');
INSERT INTO `liv_couverture` VALUES ('10','Cartonnée renforcée','2015-10-03 14:26:43','2015-10-04 14:08:14');
INSERT INTO `liv_couverture` VALUES ('11','Cartonnée recouverte','2015-10-03 14:26:58','2015-10-04 14:08:25');
INSERT INTO `liv_couverture` VALUES ('12','Souple recouverte','2015-10-03 14:27:17','2015-10-03 14:27:17');


DROP TABLE IF EXISTS `liv_ecrivain`;
CREATE TABLE `liv_ecrivain` (
  `liv_ecri_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_ecri_nom` varchar(100) COLLATE latin1_general_cs NOT NULL DEFAULT '',
  `liv_ecri_prenom` varchar(100) COLLATE latin1_general_cs DEFAULT NULL,
  `liv_ecri_nationalite` varchar(30) COLLATE latin1_general_cs DEFAULT NULL,
  `liv_ecri_remarques` text COLLATE latin1_general_cs,
  `liv_ecri_created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `liv_ecri_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_ecri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=404 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_ecrivain` VALUES ('282','Nom','Pr�nom','Nationalit�','Remarques','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('283','Albouy','Vincent',NULL,NULL,'0000-00-00 00:00:00','2015-10-03 13:35:48');
INSERT INTO `liv_ecrivain` VALUES ('284','All�gre','Claude','Fran�aise','Scientifique, vulgarisateur','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('285','Arnothy','Christine','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('286','Inconnu',NULL,NULL,NULL,'0000-00-00 00:00:00','2015-10-04 14:12:52');
INSERT INTO `liv_ecrivain` VALUES ('287','Bachmann','Richard','Am�ricaine','Nom de ville de Stephen King','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('288','Bailly','Othilie','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('289','Bazin','Herv�','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('290','Bensa�d','Norbert','Fran�aise','M�decin et journaliste','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('291','Bidault','H�l�ne','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('292','Blatrier','Jean Michel','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('293','Bleu','Fran�oise','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('294','Bodard','Lucien','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('295','Boissard','Janine','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('296','Bourin','Jeanne','','Epouse de l''�diteur Fran�ois Bourin ?','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('297','Bouvard','Philippe','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('298','Brauner','Alfred','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('299','Bret','Mich�le','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('300','Brown','Dan','Am�ricaine','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('301','Calabre','Isabelle','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('302','Capote','Truman','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('303','Cardinal','Marie','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('304','Cartland','Barbara','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('305','Chatelain','Emile','','Membre de l''institut','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('306','Chevalier','Jean','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('307','Christie','Agatha','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('308','Clerc','Roger','','N� en 1908','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('309','Cleveland','Harland','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('310','Colignon','Jean-Pierre','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('311','Coluche','Michel','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('312','Conan Doyle','Arthur','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('313','Coppens','Yves','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('314','Courcel','Pierre','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('315','Cousture','Arlette','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('316','Dard','Fr�d�ric','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('317','Dard','Patrice','Fran�aise','Le fils de Fr�d�ric','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('318','De Gans','Guy','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('319','de Laroche','Robert','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('320','Delavier','Fr�d�ric','Fran�aise','Etudes de morphologie','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('321','Demazi�re','Raymonde','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('322','Devos','Raymond','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('323','Dormann','Genevi�ve','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('324','Dorseuil','Alain','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('325','Doutreland','Pierre-Marie','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('326','Dramert','Val�rie','','Dr v�t�rinaire','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('327','du Maurier','Daphn�','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('328','Dubois','Philippe J.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('329','Duquesne','Jacques','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('330','Duquet','Marc','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('331','Fernandez','Dominique','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('332','Fierro','Alfred','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('333','Filliozat','Anne-Marie','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('334','Flaubert','Gustave','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('335','Forti','Augusto','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('336','Fosnes Hansen','Erik','Norv�gienne','N� � New-York','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('337','Gabriel','A.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('338','Gauquelin','Michel et Fran�oise','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('339','Gheerbrant','Alain','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('340','Giono','Jean','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('341','Glaister','Lesley','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('342','Golibert','Pierre','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('343','Gouriot','Jean-Marie','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('344','Graham','Patrick','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('345','Grisham','John','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('346','Guasch','G�rard','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('347','Guedj','Denis','Fran�aise','Math�maticien','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('348','H�brard','Fr�d�rique','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('349','Herbert','Franck','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('350','Higgins Clark','Mary','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('351','Hourquin','Didier','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('352','Hugo','Victor','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('353','Ionesco','Eug�ne','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('354','James','Phyllis Dorothy','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('355','Kermel','Marie','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('356','King','Stephen','Am�ricaine','Pseudonyme, �crit aussi sous son nom : Richard Bachman','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('357','King','Tabitha','Am�ricaine','Epouse de Stephen King','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('358','King','Laurie','Am�ricaine','La fille ?','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('359','Krakowiak','Sacha','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('360','Krisa','Bohdan','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('361','La Fontaine','Jean','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('362','Lacave','Mireille','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('363','Larkin','Patrick','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('364','Lef�bre','Fran�oise','Fran�aise','N�e � Paris','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('365','Ludlum','Robert','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('366','Margueritte','Yves','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('367','McCullough','Colleen','Am�ricaine','D''origine Irlandaise, n�e en Australie, �migr�e aux USA','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('368','Montagn�','Guy','Fran�aise','Humoriste','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('369','Nourissier','Fan�ois','Fran�aise','de l''acad�mie Goncourt','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('370','Patterson','James','Am�ricaine','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('371','Payri','Odile','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('372','Phythian','B.A.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('373','Ramiandrisoa','Joana','Malgache (1953)','Il arrive en France en 1961, abandonne la psychanalyse en 84 pour se consacrer � l''�ducation','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('374','Richaudeau','Fran�ois','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('375','Robine','Marc','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('376','Robotham','Michael','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('377','Rougelet','Patrick','Fran�aise','Ancien membre des R.G.','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('378','Sabatier','Robert','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('379','Salavert','Marie-H�l�ne','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('380','Salom�','Jacques','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('381','Samson','Isabelle et R�my','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('382','Savage','Tom','Am�ricaine','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('383','Schmidt','Jo�l','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('384','S�chan','Thierry','Fran�aise','Fr�re du chanteur Renaud (S�chan)','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('385','Selz','Reiner K.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('386','Shakespeare','','Anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('387','Shelley','Mary','Am�ricaine ou anglaise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('388','Sim','','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('389','Simiot','Bernard','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('390','Stanislav','Frank','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('391','Straub','Peter','Am�ricaine','A �crit conjointement avec Stephen King.','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('392','Su�tone','','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('393','Tessier','Colette','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('394','Thibaux','Jean-Michel','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('395','Thierry','Jean-Pierre','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('396','Travis','Robert','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('397','Universalis','Encyclopaedia','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('398','Van Vogt','A.E.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('399','Vernes','Jules','Fran�aise','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('400','Vincent','J.','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('401','Volkmann','Jean-Charles','','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('402','Weisman','Alan','Anglais','','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_ecrivain` VALUES ('403','Young','Robyn','','','0000-00-00 00:00:00','0000-00-00 00:00:00');


DROP TABLE IF EXISTS `liv_editeur`;
CREATE TABLE `liv_editeur` (
  `liv_edit_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_edit_nom` varchar(100) COLLATE latin1_general_cs NOT NULL DEFAULT '',
  `liv_edit_remarques` text COLLATE latin1_general_cs,
  `liv_edit_created_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `liv_edit_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`liv_edit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_editeur` VALUES ('195','Albin Michel','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('196','Anne Carri�re','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('197','Belfond','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('198','Biblioth�que du CEPL','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('199','Cariscript','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('200','Centre d''�tude et de promotion de la lecture','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('201','Chancellor press','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('202','Colleen McCullough','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('203','Dargaud','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('204','De Vecchi','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('205','Dunod','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('206','Editions de La Table Ronde','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('207','Editions de l''Archipel','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('208','Editions du Rocher','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('209','Editions du Seuil','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('210','Editions Famot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('211','Editions Fayard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('212','Editions Fixot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('213','Editions gammaprim','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('214','Editions Gisserot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('215','Editions Grasset','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('216','Editions Payot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('217','Editions Presse cit�','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('218','Editions universitaires','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('219','Encyclopaedia Universalis','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('220','Flammarion','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('221','Fleuve noir','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('222','Fran�ois Bourin','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('223','Gallimard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('224','Garnier fr�res','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('225','Gen�ve','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('226','Grasset','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('227','Gr�nd','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('228','Guild Publishing London','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('229','Hachette','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('230','Hachette litt�rature','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('231','Hatier','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('232','Inconnu','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('233','J''ai lu','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('234','Jean de Bonnot','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('235','Laffont Robert','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('236','Larousse-Bordas','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('237','Latt�s','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('238','Le cherche midi','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('239','Le Club','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('240','Le courrier du livre','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('241','Le foyer de Cachan','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('242','Le Grand Livre du Mois','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('243','Le Livre de poche','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('244','Librairie Arth�me Fayard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('245','Librio','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('246','Longman','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('247','Magnard','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('248','Maisonneuve et Larose','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('249','Mazarine','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('250','Michel Laffont','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('251','Micro Application','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('252','Oxford University Press','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('253','Parigramme','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('254','Phythian B.A.','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('255','Plon','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('256','Presses Pocket','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('257','Reader''s Digest','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('258','Rustica �ditions','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('259','Selz �ditions','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('260','Seuil','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('261','Tr�visse','',NULL,NULL);
INSERT INTO `liv_editeur` VALUES ('262','Vigot','',NULL,NULL);


DROP TABLE IF EXISTS `liv_livre`;
CREATE TABLE `liv_livre` (
  `livre_id` int(11) NOT NULL AUTO_INCREMENT,
  `livre_theme_id` int(11) NOT NULL,
  `livre_editeur_id` int(11) NOT NULL,
  `livre_couverture_id` int(11) NOT NULL,
  `livre_titre` varchar(255) COLLATE latin1_general_cs NOT NULL DEFAULT '',
  `livre_anneeCopyright` int(11) DEFAULT NULL,
  `livre_date_achat` datetime DEFAULT '0000-00-00 00:00:00',
  `livre_prix_achat` decimal(10,2) DEFAULT NULL,
  `livre_nb_pages` int(11) DEFAULT NULL,
  `livre_remarques` text COLLATE latin1_general_cs,
  `livre_a_lire` tinyint(1) NOT NULL DEFAULT '1',
  `livre_vocabulaire` tinyint(1) NOT NULL DEFAULT '0',
  `livre_en_stock` tinyint(1) NOT NULL DEFAULT '1',
  `livre_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `livre_updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`livre_id`),
  KEY `idx_livre_theme_id` (`livre_theme_id`),
  KEY `FK_editeur_idx` (`livre_editeur_id`),
  KEY `FK_couverture_idx` (`livre_couverture_id`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_livre` VALUES ('1','61','195','5','R.G.. la machine ? scandales','1997',NULL,'0.00','261','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('2','73','195','5','Rendez-vous ? la malouini?re','11',NULL,'0.00','658','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('3','78','195','5','La part des ténèbres','1989',NULL,'0.00','462',NULL,'0','0','0','0000-00-00 00:00:00','2015-10-09 15:41:14');
INSERT INTO `liv_livre` VALUES ('4','71','201','5','Sherlock Holmes','1985',NULL,'0.00','992','Ouvrage en anglais','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('5','64','208','5','Frankenstein','1988',NULL,'0.00','249',NULL,'1','0','0','0000-00-00 00:00:00','2015-10-09 15:20:07');
INSERT INTO `liv_livre` VALUES ('6','73','209','5','L''école des pères',NULL,NULL,'0.00','346',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-04 14:43:04');
INSERT INTO `liv_livre` VALUES ('7','67','220','5','Le pr?sident Balta','10',NULL,'0.00','292','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('8','73','223','5','Le hussard sur le toit','1951',NULL,'0.00','475','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('9','73','224','5','L''éducation sentimentale',NULL,NULL,'0.00','473','Marque pages en fil','1','1','1','0000-00-00 00:00:00','2015-10-04 14:44:05');
INSERT INTO `liv_livre` VALUES ('10','73','226','5','Le bonheur d''une mani?re ou d''une autre','1978',NULL,'0.00','559','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('11','73','226','5','La chasse à l''ours','1985',NULL,'0.00','470',NULL,'0','1','-1','0000-00-00 00:00:00','2015-10-09 15:37:31');
INSERT INTO `liv_livre` VALUES ('12','73','226','5','Les grands d?sordres','1987',NULL,'0.00','290','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('13','62','195','6','L''orthographe. c''est logique !','2003',NULL,'0.00','219','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('14','64','195','6','Cellulaire','2006','2007-01-03 00:00:00','22.00','403',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:00:20');
INSERT INTO `liv_livre` VALUES ('15','64','195','6','22/11/1963','2013','2013-05-01 00:00:00','25.90','937',NULL,'0','1','-1','0000-00-00 00:00:00','2015-10-07 20:49:54');
INSERT INTO `liv_livre` VALUES ('16','64','195','6','Joyland','2013','2014-08-08 00:00:00','20.30','325',NULL,'0','1','-1','0000-00-00 00:00:00','2015-10-09 15:33:22');
INSERT INTO `liv_livre` VALUES ('17','64','195','6','Docteur Sleep','2013','2014-08-08 00:00:00','25.00','587',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:12:24');
INSERT INTO `liv_livre` VALUES ('18','71','195','6','Baze','2008','2008-04-25 00:00:00','19.90','328',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 14:55:47');
INSERT INTO `liv_livre` VALUES ('19','78','195','6','Deux petites filles en bleu','2006','2007-07-26 00:00:00','22.00','420',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 15:04:36');
INSERT INTO `liv_livre` VALUES ('20','78','195','6','Histoire de Lisey','2007','2008-03-20 00:00:00','22.50','572',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:27:13');
INSERT INTO `liv_livre` VALUES ('21','78','195','6','Dôme T1','2009','2011-01-01 00:00:00','22.00','631',NULL,'0','1','-1','0000-00-00 00:00:00','2015-10-09 15:13:01');
INSERT INTO `liv_livre` VALUES ('22','78','195','6','Dôme T2','2009','2011-11-01 00:00:00','22.00','566',NULL,'0','1','-1','0000-00-00 00:00:00','2015-10-09 15:13:43');
INSERT INTO `liv_livre` VALUES ('23','78','196','6','L''?vangile selon Satan','29',NULL,'21.00','526','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('24','71','197','6','Soleil de plomb','28',NULL,'19.00','418','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('25','73','202','6','Les oiseaux se cachent pour mourir','1982',NULL,'0.00','536','Frace Loisirs','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('26','69','203','6','Principe des systh?mes d''exploitation des ordinateurs','1985',NULL,'30.00','436','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('28','65','204','6','Je mange sain. mais je mange bien','1987',NULL,'0.00','270',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:31:40');
INSERT INTO `liv_livre` VALUES ('29','73','206','6','Emilie','1988',NULL,'0.00','523',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 15:15:46');
INSERT INTO `liv_livre` VALUES ('30','61','207','6','Paroles de chat','1999',NULL,'0.00','259','Documentaire romanc? sur les chats. tr?s bien fait.','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('31','75','209','6','Le th?or?me du perroquet','10',NULL,'0.00','658','Pr?sentation et histoire des maths sous forme romanc?es.','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('32','80','209','6','O? les eaux se partagent (chroniques siciliennes)','2005',NULL,'0.00','96','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('33','71','211','6','San-Antonio contre San-Antonio','28',NULL,'15.00','306','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('34','71','211','6','San-Antonio Shocking!','28',NULL,'15.00','270','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('35','71','211','6','San-Antonio Vingt mille n?uds sous les mers','28',NULL,'15.00','297','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('36','71','211','6','San-Antono s''envole en l''air','29',NULL,'15.00','297','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('37','75','211','6','Un peu plus de science pour tout le monde','28',NULL,'23.00','511','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('38','60','213','6','Anglais : grammaire. expression et méthodes','1995',NULL,'0.00','108','Seconde. première. terminale.','0','0','-1','0000-00-00 00:00:00','2015-10-07 20:59:27');
INSERT INTO `liv_livre` VALUES ('39','71','215','6','La vendetta Lazare','28',NULL,'19.00','392','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('41','73','217','6','La pyramide perdue','28',NULL,'19.00','338','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('42','60','220','6','Dictionnaire anglais-français / français-anglais','1976',NULL,'0.00','393','Année du Copyright : 1964, pas dans la liste','0','0','-1','0000-00-00 00:00:00','2015-10-09 15:07:07');
INSERT INTO `liv_livre` VALUES ('43','75','220','6','Homo disparitus','2007','2007-07-26 00:00:00','19.90','397','Admettons que le pire soit arrivé. Imaginons un monde dont nous aurions tous soudain disparus. Et voyons ce qu''il reste.','1','0','-1','0000-00-00 00:00:00','2015-10-09 15:29:15');
INSERT INTO `liv_livre` VALUES ('44','78','220','6','Le singe, Le chenal','1994',NULL,'1.00','96','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('45','71','221','6','L''otage du délégué',NULL,NULL,'0.00','219',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-04 14:47:48');
INSERT INTO `liv_livre` VALUES ('46','71','221','6','Pi?ge ? Naqoura','1996',NULL,'0.00','213','Lieutenant ZAC','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('47','81','223','6','Rhinoc?ros','1972',NULL,'0.00','246','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('49','59','233','6','Georges Brassens. histoire d''une vie','1993',NULL,'0.00','368',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:20:31');
INSERT INTO `liv_livre` VALUES ('50','67','233','6','Anatomie de l''horreur - 2','2003','2008-11-02 00:00:00','6.50','378',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 14:53:32');
INSERT INTO `liv_livre` VALUES ('51','73','233','6','Vip?re au poing','0',NULL,'0.00','256','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('52','73','233','6','Le petit prince cannibale','1991',NULL,'0.00','178','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('53','78','233','6','Le fl?au','1981',NULL,'5.00','572','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('54','78','233','6','Danse macabre','1993',NULL,'0.00','411',NULL,'0','0','0','0000-00-00 00:00:00','2015-10-09 15:02:23');
INSERT INTO `liv_livre` VALUES ('55','78','233','6','Rage','1990',NULL,'3.00','250','A l''?colde de l''enfert','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('56','78','233','6','Ca. tome 2','1990','1993-04-19 00:00:00','5.56','510',NULL,'0','0','0','0000-00-00 00:00:00','2015-10-09 14:56:50');
INSERT INTO `liv_livre` VALUES ('57','78','233','6','La tour sombre. terres perdues','1993',NULL,'0.00','570','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('58','78','233','6','Carrie','1992',NULL,'3.61','253',NULL,'0','0','0','0000-00-00 00:00:00','2015-10-09 14:58:40');
INSERT INTO `liv_livre` VALUES ('59','78','233','6','Marche ou cr?ve','1994',NULL,'0.00','345','Ils sont 100 au d?part. 1 ? l''arriv?e. une balle dans la t?te pour les autres.','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('60','78','233','6','Minuit 2','1991',NULL,'0.00','564','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('61','78','233','6','La tour sombre. les trois cartes','13',NULL,'0.00','499','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('62','78','233','6','Ca. tome 3','1990',NULL,'5.56','502',NULL,'0','0','0','0000-00-00 00:00:00','2015-10-09 14:57:15');
INSERT INTO `liv_livre` VALUES ('63','78','233','6','Anatomie de l''horreur - 1','1981','2008-12-14 00:00:00','6.70','379',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 14:53:01');
INSERT INTO `liv_livre` VALUES ('64','66','235','6','Histoire et dictionnaire de Paris','1996',NULL,'28.51','1580',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 15:27:41');
INSERT INTO `liv_livre` VALUES ('65','76','235','6','Le cycle de Dune : Dune 1','1965',NULL,'5.00','349','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('66','76','235','6','Le cycle de Dune : Dune 2','18',NULL,'5.00','572','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('67','76','235','6','Le cycle de Dune : Le Messie de Dune','2',NULL,'5.00','314','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('68','76','235','6','Le cycle de Dune : Les enfants de Dune','5',NULL,'6.00','539','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('69','73','237','6','Traqu?e','16',NULL,'0.00','318','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('70','73','237','6','La disparue','2006','2007-01-03 00:00:00','20.00','455',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:38:52');
INSERT INTO `liv_livre` VALUES ('71','64','239','6','La tour sombre 1 : Le pistolero','4',NULL,'15.00','255','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('72','64','239','6','La tour sombre 2 : Terres perdues','13',NULL,'21.00','522','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('73','64','239','6','La tour sombre 3 : Les trois cartes','9',NULL,'19.00','399','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('74','64','239','6','La tour sombre 4 : Magie et cristal','19',NULL,'24.00','863','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('75','64','239','6','La tour sombre 5 : Les loups de la Calla','25',NULL,'23.00','668','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('76','64','239','6','La tour sombre 6 : Le chant de Susannah','26',NULL,'21.00','525','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('77','64','239','6','La tour sombre 7 : La Tour Sombre','26',NULL,'29.00','953','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('78','65','240','6','Diagnostic de la personnalité','1989',NULL,'18.29','251','Une méthode de psychologie objective','1','0','-1','0000-00-00 00:00:00','2015-10-09 15:05:34');
INSERT INTO `liv_livre` VALUES ('79','73','241','6','Le vieux reptile','1994',NULL,'0.00','191','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('80','61','242','6','Les oiseaux du jardin','30',NULL,'19.00','128','Achat de 2 livre dont 1 offert ? Isabelle pour son anniversaire.\r\n+ CD audio de chants d''oiseaux.','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('82','61','242','6','La passion des oiseaux','2010','2010-10-20 00:00:00','29.00','332','Offrert à Isabelle pour son anniversaire','0','0','-1','0000-00-00 00:00:00','2015-10-09 15:42:23');
INSERT INTO `liv_livre` VALUES ('83','64','243','6','Dreamcatcher','2003','2011-05-25 00:00:00','7.50','886',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 15:15:19');
INSERT INTO `liv_livre` VALUES ('84','73','243','6','Un tour sur le Bolid''','22',NULL,'2.00','95','Titre original : Riding the bullet','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('85','78','243','6','Running man','4',NULL,'5.00','316','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('86','78','245','6','La ballade de la balle élastique + L''homme qui refusait de serrer la main','1995',NULL,'0.00','96',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:35:12');
INSERT INTO `liv_livre` VALUES ('87','63','247','6','La Cadillac de Dolan','1993','2011-05-25 00:00:00','4.50','142','Etude littéraire','1','0','-1','0000-00-00 00:00:00','2015-10-09 15:36:51');
INSERT INTO `liv_livre` VALUES ('89','75','248','6','La mort de Newton','1996',NULL,'0.00','143','Préface de Stephen Hawking','1','1','-1','0000-00-00 00:00:00','2015-10-09 15:40:22');
INSERT INTO `liv_livre` VALUES ('90','69','251','6','VB.NET','24',NULL,'1.00','368','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('91','59','253','6','Les lieux cultes des ?crivains','30',NULL,'0.00','64','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('92','76','256','6','Le cycle de Dune : Les h?r?tiques de Dune','0',NULL,'0.00','492','Le cycle de Dune','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('93','74','260','6','Le sommeil de la raison. une méthode : les médecines douces',NULL,NULL,'0.00','270',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-04 17:02:22');
INSERT INTO `liv_livre` VALUES ('94','65','262','6','Guide des mouvements de musculation','2001','2001-07-28 00:00:00','19.67','124','Planches et illustrations en couleur.','0','0','-1','0000-00-00 00:00:00','2015-10-09 15:24:13');
INSERT INTO `liv_livre` VALUES ('95','78','195','7','Chantier',NULL,NULL,'5.49','0',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:01:04');
INSERT INTO `liv_livre` VALUES ('96','65','199','7','Yoga ? Oui ? mais ? démystifier pour atteindre le réel',NULL,NULL,'13.00','208',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-04 14:50:13');
INSERT INTO `liv_livre` VALUES ('97','76','233','7','Au-delà du village enchanté','1987',NULL,'0.00','313',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-07 21:00:37');
INSERT INTO `liv_livre` VALUES ('98','65','195','8','Le ventre plat c''est facile','1984',NULL,'0.00','140','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('99','71','195','8','Meutre ? Cape Cod','13',NULL,'0.00','110','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('100','71','195','8','Kidnapping','2000','2000-05-30 00:00:00','0.00','311',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 15:34:08');
INSERT INTO `liv_livre` VALUES ('101','72','195','8','Heureux qui communique','1993',NULL,'8.89','94',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:25:47');
INSERT INTO `liv_livre` VALUES ('102','73','195','8','L''envol des tourterelles','17',NULL,'0.00','406','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('103','73','195','8','La petite main','15',NULL,'0.00','303','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('105','74','195','8','Aide-toi. ton corps t''aidera','2006','2007-01-03 00:00:00','24.50','331','Livré avec un CD-ROM','1','0','-1','0000-00-00 00:00:00','2015-10-09 14:50:58');
INSERT INTO `liv_livre` VALUES ('106','78','195','8','Les r?gulateurs','18',NULL,'0.00','388','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('107','78','195','8','La temp?te du si?cle','1999',NULL,'0.00','442','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('108','78','195','8','Insomnie','1995',NULL,'0.00','717',NULL,'0','0','0','0000-00-00 00:00:00','2015-10-09 15:30:57');
INSERT INTO `liv_livre` VALUES ('109','78','195','8','Les ?vad?s','1995',NULL,'0.00','529','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('110','78','195','8','Jessie','1992',NULL,'0.00','389',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:32:44');
INSERT INTO `liv_livre` VALUES ('111','78','195','8','Sac d''os','21',NULL,'22.00','600','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('112','78','195','8','La petite fille qui aimait Tom Gordon','1999',NULL,'19.00','333','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('113','78','195','8','Coeurs perdus en Atlantide','1999','2001-05-01 00:00:00','22.87','553',NULL,'0','1','-1','0000-00-00 00:00:00','2015-10-09 15:01:49');
INSERT INTO `liv_livre` VALUES ('114','78','195','8','Le meurtre de la Saint Valentin','19',NULL,'7.00','342','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('115','72','208','8','Dictionnaire des rêves','1990',NULL,'0.00','386',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:08:26');
INSERT INTO `liv_livre` VALUES ('116','61','212','8','L''argent des fonctionnaires','1998',NULL,'0.00','225','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('117','65','212','8','La méthode Arthur','1992',NULL,'0.00','293','Comment d?velopper dans l''harmonie les capacit?s naturelles de votre enfant','1','0','-1','0000-00-00 00:00:00','2015-10-09 15:39:30');
INSERT INTO `liv_livre` VALUES ('118','66','214','8','Histoire de France','1998','2001-02-05 00:00:00','0.00','341','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','1','1','0','0000-00-00 00:00:00','2015-10-09 15:26:31');
INSERT INTO `liv_livre` VALUES ('119','73','218','8','Les carnets noirs','1980',NULL,'0.00','179','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('120','71','221','8','Napol?on Pommier','22',NULL,'1.00','319','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('121','73','229','8','Paris au XX?me si?cle','1996',NULL,'0.00','216','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('122','66','230','8','Les paysans fran?ais','22',NULL,'14.00','295','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('123','64','235','8','Le talisman des territoires : Territoires','24',NULL,'2.00','551','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('124','64','235','8','Le talisman des territoires : Territoires','24',NULL,'2.00','551','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('125','78','235','8','Le testament','2000',NULL,'7.00','445','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('126','78','235','8','Le talisman des territoires : Talisman','24',NULL,'0.00','646','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('128','73','237','8','Salem','29',NULL,'25.00','620','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('129','73','237','8','Rouges sont les roses','2002',NULL,'0.00','350','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('130','67','238','8','Pens?es et anecdotes','17',NULL,'0.00','247','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('131','67','238','8','Le Best off','2000',NULL,'8.00','186','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('132','78','242','8','L''âme du temple : Le Livre du Cercle',NULL,NULL,'21.00','727',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-04 14:44:56');
INSERT INTO `liv_livre` VALUES ('133','66','244','8','Le singe. l''Affrique et l''homme','22',NULL,'13.00','150','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('134','71','244','8','Un pompier nomm? B?ru','24',NULL,'2.00','276','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('135','67','250','8','Brêves de comptoir 1996','1996',NULL,'0.00','285',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-07 21:02:08');
INSERT INTO `liv_livre` VALUES ('136','67','255','8','Un jour sans moi','1996',NULL,'0.00','182','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('137','61','258','8','Décodez le langage de votre chat !','2009','2011-01-01 00:00:00','14.50','111','Acheté 2. dont 1 pour offrir à Isabelle','0','0','-1','0000-00-00 00:00:00','2015-10-09 15:03:30');
INSERT INTO `liv_livre` VALUES ('138','73','195','9','Rebecca','22',NULL,'0.00','390','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('139','78','195','9','Les yeux du dragon','1995',NULL,'0.00','382','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('140','62','198','9','La psychologie de l''enfant de A ? Z','1976',NULL,'0.00','543','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('143','65','203','9','L''art des Bonsa?s','1985',NULL,'0.00','224','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('144','65','210','9','Tests et personnalit?','1978',NULL,'0.00','256','Notre personnalit? par les tests','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('145','65','210','9','Graphologie','1978',NULL,'0.00','251','Traité de graphologie : le caractère par l''écriture','1','1','-1','0000-00-00 00:00:00','2015-10-09 15:22:02');
INSERT INTO `liv_livre` VALUES ('146','73','223','9','Petit d?jeuner chez Tiffany','1962',NULL,'0.00','178','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('147','73','223','9','Un roi sans divertissement','1995',NULL,'0.00','209','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('148','73','223','9','Provence','1993',NULL,'0.00','314','Marque page fil','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('149','73','223','9','La chasse au bonheur','1988',NULL,'0.00','212',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 15:38:11');
INSERT INTO `liv_livre` VALUES ('150','73','223','9','Le chant du monde','1934',NULL,'0.00','281','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('151','60','229','9','Dictionnaire français-latin','1984',NULL,'0.00','1551',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:08:59');
INSERT INTO `liv_livre` VALUES ('152','60','231','9','Dictionnaire latin-français','1976',NULL,'0.00','751','Année du Copyright : 1960, pas dans la liste','0','1','-1','0000-00-00 00:00:00','2015-10-09 15:10:40');
INSERT INTO `liv_livre` VALUES ('153','60','235','9','Dictionnaires des symboles','1982',NULL,'0.00','1060','Mythes. rêves. coutumes. gestes. formes. figures. couleurs. nombres.','1','0','-1','0000-00-00 00:00:00','2015-10-09 15:11:45');
INSERT INTO `liv_livre` VALUES ('155','60','236','9','Dictionnaire de la mythologie grèque et romaine','1998',NULL,'0.00','206',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-09 15:07:53');
INSERT INTO `liv_livre` VALUES ('156','62','227','9','Encyclopédie des plantes à fleurs','1982',NULL,'0.00','351','Photos couleur','0','0','0','0000-00-00 00:00:00','2015-10-09 15:17:36');
INSERT INTO `liv_livre` VALUES ('157','71','249','9','Sans les mains','1988',NULL,'0.00','237','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('158','65','259','9','Le guide de tout ce qui est gratuit','1993',NULL,'0.00','348','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('160','66','219','10','Miroir du moyen-?ge : 1/ Les ?v?nements','21',NULL,'24.00','382','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('161','66','219','10','Miroir du moyen-?ge : 2/ Institutions. Figurines. Savoirs','21',NULL,'24.00','383','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('162','73','225','10','Les mis?rables. tome III','0',NULL,'0.00','463','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('163','70','229','10','Fables','1976',NULL,'0.00','332','Année du Copyright : 1973, pas dans la liste','1','0','-1','0000-00-00 00:00:00','2015-10-09 15:19:39');
INSERT INTO `liv_livre` VALUES ('164','73','229','10','Notre Dame de Paris','1973',NULL,'0.00','443','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('165','81','229','10','Hamlet. Othello. Macbeth','1976',NULL,'0.00','385','Année du Copyright  : 1973, pas dans la liste','1','0','-1','0000-00-00 00:00:00','2015-10-09 15:25:18');
INSERT INTO `liv_livre` VALUES ('166','66','234','10','Les vies des douzes C?sars. empereurs romains','1983',NULL,'0.00','325','Edition de qualit?. gravures. illustrations.','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('167','65','257','10','Guide de la route','2001','2001-06-13 00:00:00','34.15','500','Edition 2001. France routière et touristique','0','0','-1','0000-00-00 00:00:00','2015-10-09 15:23:07');
INSERT INTO `liv_livre` VALUES ('168','73','195','11','La souris verte','12',NULL,'0.00','283','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('169','65','200','11','Méthode de lecture pratique. tome 2',NULL,NULL,'0.00','348',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-04 16:52:20');
INSERT INTO `liv_livre` VALUES ('170','65','200','11','Méthode de lecture rapide. tome 1',NULL,NULL,'0.00','523',NULL,'1','1','-1','0000-00-00 00:00:00','2015-10-04 16:50:57');
INSERT INTO `liv_livre` VALUES ('173','73','208','11','L''enfant dans le placard','1989',NULL,'0.00','138','','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('174','65','209','11','La bonne cuisine et les autres','1986',NULL,'0.00','281',NULL,'0','0','-1','0000-00-00 00:00:00','2015-10-09 15:35:49');
INSERT INTO `liv_livre` VALUES ('175','61','216','11','Montpellier nagu?re','1981',NULL,'0.00','207','Nombreuses photos N&B','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('176','73','222','11','Les P?r?grines','1989',NULL,'0.00','446','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('177','73','226','11','Catherine Courage','1990',NULL,'0.00','273','La fille de Maria Vandamme','0','0','-1','0000-00-00 00:00:00','2015-10-09 14:59:28');
INSERT INTO `liv_livre` VALUES ('178','73','226','11','Le gardien des ruines','1992',NULL,'0.00','350','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('179','60','228','11','The MacMillan Encyclopedia','1989',NULL,'0.00','1336','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('180','73','235','11','Une femme en blanc','18',NULL,'0.00','494','Suivi de Jeanne R.','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('181','67','237','11','Les fous rires des grosses t?tes','9',NULL,'0.00','249','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('182','62','242','11','Les poissons d''aquarium','1995',NULL,'12.00','256','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('183','71','242','11','T6 : Les ann?es 1938-1940','25',NULL,'23.00','1182','Rendez-vaous avec la mort.\r\nLe no?l d''Hercule Poirot.\r\nUn meurtre est-il facile ?\r\nDix petits n?gres.\r\nUn. deux. trois.\r\nJe ne suis pas coupable.','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('184','71','242','11','T2 : Les ann?es 1926-1930','25',NULL,'22.00','1264','Le meurtre de Roger Ackroyd.\r\nLes quatre.\r\nLe train bleu.\r\nLes sept cadrans.\r\nLe crime est notre affaire.\r\nL''affaire protheroe.','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('185','71','242','11','T1 : Les années 1920-1925',NULL,NULL,'23.00','1301','La myst?rieuse affaire de styles.Mr Brown.Le crime du golf.L''homme au complet marron.Les enqu?tes d''Hercule Poirot.Le secret de Chimneys.','1','1','-1','0000-00-00 00:00:00','2015-10-04 16:53:57');
INSERT INTO `liv_livre` VALUES ('186','71','242','11','T9 : Les ann?es 1949-1953','25',NULL,'23.00','1205','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('187','60','246','11','The original Roget''s thesaurus of English words and idioms','1987',NULL,'0.00','1254','Dictionnaire en englais','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('188','60','252','11','The Oxford reference dictionary','1989',NULL,'0.00','978','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('189','60','254','11','English Idioms','1986',NULL,'0.00','250',NULL,'1','0','0','0000-00-00 00:00:00','2015-10-09 15:18:20');
INSERT INTO `liv_livre` VALUES ('190','73','255','11','Cantique pour la fin du voyage','1996',NULL,'0.00','497',NULL,'1','0','-1','0000-00-00 00:00:00','2015-10-09 14:58:05');
INSERT INTO `liv_livre` VALUES ('191','73','261','11','Que notre bonheur dure','1980',NULL,'0.00','247','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('192','73','261','11','L''enchantement du d?sert','1980',NULL,'0.00','215','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `liv_livre` VALUES ('193','73','220','12','Le ch?teau des Oliviers','1993',NULL,'0.00','410','','0','1','-1','0000-00-00 00:00:00','0000-00-00 00:00:00');


DROP TABLE IF EXISTS `liv_theme`;
CREATE TABLE `liv_theme` (
  `liv_them_id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_them_libelle` varchar(100) COLLATE latin1_general_cs NOT NULL DEFAULT '',
  `liv_them_created_on` timestamp NULL DEFAULT NULL,
  `liv_them_updated_on` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`liv_them_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `liv_theme` VALUES ('58','Affaires',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('59','Bibliographie',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('60','Dictionnaire',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('61','Documentaire',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('62','Encyclopédie',NULL,'2015-10-04 14:06:27');
INSERT INTO `liv_theme` VALUES ('63','Essais - études',NULL,'2015-10-04 14:06:36');
INSERT INTO `liv_theme` VALUES ('64','Fantastique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('65','Guide pratique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('66','Histoire',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('67','Humour',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('68','Inconnu',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('69','Informatique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('70','Poésie',NULL,'2015-10-04 14:06:46');
INSERT INTO `liv_theme` VALUES ('71','Policier',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('72','Psychologie',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('73','Roman',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('74','Santé',NULL,'2015-10-04 14:06:03');
INSERT INTO `liv_theme` VALUES ('75','Science',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('76','Science-fiction',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('77','Sentimental',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('78','Suspence',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('79','Technique',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('80','Terroir',NULL,NULL);
INSERT INTO `liv_theme` VALUES ('81','Théatre',NULL,'2015-10-04 14:06:56');


DROP TABLE IF EXISTS `tmp`;
CREATE TABLE `tmp` (
  `NomFamille` text COLLATE latin1_general_cs,
  `Prenom` text COLLATE latin1_general_cs,
  `Sujet` text COLLATE latin1_general_cs,
  `NomEditeur` text COLLATE latin1_general_cs,
  `TypeDeCouverture` text COLLATE latin1_general_cs,
  `Titre` text COLLATE latin1_general_cs,
  `AnneeCopyright` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `DateAchat` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `PrixAchat` double DEFAULT NULL,
  `Pages` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `Remarques` text COLLATE latin1_general_cs,
  `LireOuRelire` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `Vocabulaire` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `EnStock` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `tmp` VALUES ('Salom�','Jacques','Psychologie','Albin Michel','Cartonn?e souple','Heureux qui communique','1993','','8','94','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Filliozat','Anne-Marie','Sant�','Albin Michel','Cartonn?e souple','Aide-toi. ton corps t''aidera','28/06/1905','39 085.00','24','331','Livr? avec un CD-ROM','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Guasch','G�rard','Sant�','Albin Michel','Cartonn?e souple','Aide-toi. ton corps t''aidera','28/06/1905','03/01/2007','24','331','Livr? avec un CD-ROM','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Molle','Chantier','','','5','','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e souple','La temp?te du si?cle','1999','01/07/1999','0','442','','FAUX','VRAI','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e souple','Insomnie','1995','','0','717','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e','La part des t?n?bres','11/06/1905','','0','462','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('Bachmann','Richard','Suspence','Albin Michel','Cartonn?e souple','Les r?gulateurs','18/06/1905','','0','388','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e souple','Les ?vad?s','1995','','0','529','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e souple','Jessie','14/06/1905','','0','389','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e rigide','Les yeux du dragon','1995','','0','382','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('Savage','Tom','Suspence','Albin Michel','Cartonn?e souple','Le meurtre de la Saint Valentin','19/06/1905','36 676.00','7','342','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e souple','Sac d''os','21/06/1905','36 676.00','22','600','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e souple','La petite fille qui aimait Tom Gordon','1999','30/05/2000','19','333','','FAUX','VRAI','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Cartonn?e souple','C?urs perdus en Atlantide','1999','01/05/2001','22','553','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Higgins Clark','Mary','Suspence','Albin Michel','Souple','Deux petites filles en bleu','2006','39 289.00','22','420','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Souple','Histoire de Lisey','2007','20/03/2008','22','572','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Souple','D?me T1','2009','01/11/2011','22','631','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Albin Michel','Souple','D?me T2','01/07/1905','40 848.00','22','566','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Dormann','Genevi�ve','Roman','Albin Michel','Cartonn?e souple','La petite main','15/06/1905','','0','303','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Simiot','Bernard','Roman','Albin Michel','Cartonn?e','Rendez-vous ? la malouini?re','11/06/1905','','0','658','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Sabatier','Robert','Roman','Albin Michel','Cartonn?e recouverte','La souris verte','12/06/1905','','0','283','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Cousture','Arlette','Roman','Albin Michel','Cartonn?e souple','L''envol des tourterelles','17/06/1905','','0','406','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('du Maurier','Daphn�','Roman','Albin Michel','Cartonn?e rigide','Rebecca','22/04/1905','','0','390','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Albin Michel','Souple','Cellulaire','28/06/1905','39 085.00','22','403','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Albin Michel','Souple','22/11/1963','05/07/1905','41 395.00','25','937','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Albin Michel','Souple','Joyland','2013','08/08/2014','20','325','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Albin Michel','Souple','Docteur Sleep','2013','08/08/2014','25','587','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Higgins Clark','Mary','Policier','Albin Michel','Cartonn?e souple','Meutre ? Cape Cod','13/06/1905','','0','110','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Laurie','Policier','Albin Michel','Cartonn?e souple','Kidnapping','22/06/1905','30/05/2000','0','311','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bachmann','Richard','Policier','Albin Michel','Souple','Baze','30/06/1905','39 563.00','19','328','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Payri','Odile','Guide pratique','Albin Michel','Cartonn?e souple','Le ventre plat c''est facile','1984','','0','140','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('Rougelet','Patrick','Documentaire','Albin Michel','Cartonn?e','R.G.. la machine ? scandales','1997','','0','261','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Colignon','Jean-Pierre','Encyclop�die','Albin Michel','Souple','L''orthographe. c''est logique !','2003','01/07/2005','0','219','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('La Fontaine','Jean','Po�sie','Hachette','Cartonn?e renforc?e','Fables','1973','','0','332','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Vernes','Jules','Roman','Hachette','Cartonn?e souple','Paris au XX?me si?cle','1996','','0','216','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Hugo','Victor','Roman','Hachette','Cartonn?e renforc?e','Notre Dame de Paris','1973','','0','443','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Shakespeare','','Th�atre','Hachette','Cartonn?e renforc?e','Hamlet. Othello. Macbeth','1973','','0','385','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Chatelain','Emile','Dictionnaire','Hachette','Cartonn?e rigide','Dictionnaire fran?ais-latin','1984','','0','1551','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Guedj','Denis','Science','Editions du Seuil','Souple','Le th?or?me du perroquet','10/06/1905','01/08/2005','0','658','Pr?sentation et histoire des maths sous forme romanc?es.','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Bazin','Herv�','Roman','Editions du Seuil','Cartonn?e','L''?cole des p?res','1991','','0','346','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Doutreland','Pierre-Marie','Guide pratique','Editions du Seuil','Cartonn?e recouverte','La bonne cuisine et les autres','08/06/1905','','0','281','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Fernandez','Dominique','Terroir','Editions du Seuil','Souple','O? les eaux se partagent (chroniques siciliennes)','2005','10/12/2005','0','96','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Margueritte','Yves','Psychologie','Editions du Rocher','Cartonn?e souple','Dictionnaire des r?ves','1990','','0','386','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bailly','Othilie','Roman','Editions du Rocher','Cartonn?e recouverte','L''enfant dans le placard','1989','','0','138','','VRAI','FAUX','0');
INSERT INTO `tmp` VALUES ('Shelley','Mary','Fantastique','Editions du Rocher','Cartonn?e','Frankenstein','1988','','0','249','','VRAI','FAUX','0');
INSERT INTO `tmp` VALUES ('Arnothy','Christine','Roman','Grasset','Cartonn?e','Le bonheur d''une mani?re ou d''une autre','1978','','0','559','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Cardinal','Marie','Roman','Grasset','Cartonn?e','Les grands d?sordres','1987','','0','290','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Duquesne','Jacques','Roman','Grasset','Cartonn?e recouverte','Catherine Courage','1990','','0','273','La fille de Maria Vandamme','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bodard','Lucien','Roman','Grasset','Cartonn?e','La chasse ? l''ours','1985','','0','470','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Nourissier','Fan�ois','Roman','Grasset','Cartonn?e recouverte','Le gardien des ruines','1992','','0','350','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Giono','Jean','Roman','Gallimard','Cartonn?e','Le hussard sur le toit','1951','','0','475','','VRAI','VRAI','-1');
INSERT INTO `tmp` VALUES ('Giono','Jean','Roman','Gallimard','Cartonn?e rigide','Un roi sans divertissement','1995','','0','209','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Capote','Truman','Roman','Gallimard','Cartonn?e rigide','Petit d?jeuner chez Tiffany','1962','','0','178','','VRAI','FAUX','0');
INSERT INTO `tmp` VALUES ('Giono','Jean','Roman','Gallimard','Cartonn?e rigide','Provence','1993','','0','314','Marque page fil','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Giono','Jean','Roman','Gallimard','Cartonn?e rigide','La chasse au bonheur','1988','','0','212','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Giono','Jean','Roman','Gallimard','Cartonn?e rigide','Le chant du monde','1934','','0','281','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Ionesco','Eug�ne','Th�atre','Gallimard','Souple','Rhinoc?ros','1972','','0','246','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Conan Doyle','Arthur','Policier','Chancellor press','Cartonn?e','Sherlock Holmes','1985','','0','992','Ouvrage en anglais','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Gouriot','Jean-Marie','Humour','Michel Laffont','Cartonn?e souple','Br?ves de comptoir 1996','1996','','0','285','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('James','Phyllis Dorothy','Policier','Mazarine','Cartonn?e rigide','Sans les mains','1988','','0','237','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Coluche','Michel','Humour','Le cherche midi','Cartonn?e souple','Pens?es et anecdotes','17/06/1905','','0','247','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Montagn�','Guy','Humour','Le cherche midi','Cartonn?e souple','Le Best off','2000','01/05/2001','8','186','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Weisman','Alan','Science','Flammarion','Souple','Homo disparitus','2007','26/07/2007','19','397','Admettons que le pire soit arriv?. Imaginons un monde dont nous aurions tous soudain disparus. Et voyons ce qu''il reste?','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Flammarion','Souple','Le singe, Le chenal','1994','','1','96','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('H�brard','Fr�d�rique','Roman','Flammarion','Souple recouverte','Le ch?teau des Oliviers','1993','','0','410','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Sim','','Humour','Flammarion','Cartonn?e','Le pr?sident Balta','10/06/1905','','0','292','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Vincent','J.','Dictionnaire','Flammarion','Souple','Dictionnaire anglais-fran?ais / fran?ais-anglais','1964','','0','393','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bidault','H�l�ne','Encyclop�die','Biblioth�que du CEPL','Cartonn?e rigide','La psychologie de l''enfant de A ? Z','1976','','0','543','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Brauner','Alfred','Encyclop�die','Biblioth�que du CEPL','Cartonn?e rigide','La psychologie de l''enfant de A ? Z','1976','','0','543','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bret','Mich�le','Encyclop�die','Biblioth�que du CEPL','Cartonn?e rigide','La psychologie de l''enfant de A ? Z','1976','','0','543','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Krisa','Bohdan','Encyclop�die','Le Grand Livre du Mois','Cartonn?e rigide','Encyclop?die des plantes ? fleurs','1982','','0','351','Photos couleur','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('Stanislav','Frank','Encyclop�die','Le Grand Livre du Mois','Cartonn?e recouverte','Les poissons d''aquarium','1995','','12','256','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Aucun','Auteur','Dictionnaire','Longman','Cartonn?e recouverte','The original Roget''s thesaurus of English words and idioms','1987','','0','1254','Dictionnaire en englais','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Hugo','Victor','Roman','Gen�ve','Cartonn?e renforc?e','Les mis?rables. tome III','','','0','463','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Forti','Augusto','Science','Maisonneuve et Larose','Souple','La mort de Newton','1996','','0','143','Pr?face de Stephen Hawling','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Cleveland','Harland','Science','Maisonneuve et Larose','Souple','La mort de Newton','1996','','0','143','Pr?face de Stephen Hawling','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Tessier','Colette','Roman','Editions universitaires','Cartonn?e souple','Les carnets noirs','1980','','0','179','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Lacave','Mireille','Documentaire','Editions Payot','Cartonn?e recouverte','Montpellier nagu?re','1981','','0','207','Nombreuses photos N&B','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Tabitha','Roman','Latt�s','Souple','Traqu?e','16/06/1905','','0','318','','VRAI','FAUX','0');
INSERT INTO `tmp` VALUES ('Patterson','James','Roman','Latt�s','Cartonn?e souple','Rouges sont les roses','2002','30/10/2002','0','350','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Robotham','Michael','Roman','Latt�s','Souple','La disparue','2006','03/01/2007','20','455','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Roman','Latt�s','Cartonn?e souple','Salem','29/06/1905','39 527.00','25','620','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bouvard','Philippe','Humour','Latt�s','Cartonn?e recouverte','Les fous rires des grosses t?tes','09/06/1905','','0','249','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Fosnes Hansen','Erik','Roman','Plon','Cartonn?e recouverte','Cantique pour la fin du voyage','1996','','0','497','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Devos','Raymond','Humour','Plon','Cartonn?e souple','Un jour sans moi','1996','','0','182','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Humour','J''ai lu','Souple','Anatomie de l''horreur - 2','2003','02/11/2008','6','378','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Le fl?au','1981','','5','572','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Danse macabre','1993','','0','411','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Rage','1990','','3','250','A l''?colde de l''enfert','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Ca. tome 2','1990','19/04/1993','5','510','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','La tour sombre. terres perdues','1993','','0','570','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Carrie','1992','','3','253','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Marche ou cr?ve','1994','','0','345','Ils sont 100 au d?part. 1 ? l''arriv?e. une balle dans la t?te pour les autres.','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Minuit 2','1991','','0','564','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','La tour sombre. les trois cartes','13/06/1905','','0','499','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Ca. tome 3','1990','','5','502','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','J''ai lu','Souple','Anatomie de l''horreur - 1','1981','14/12/2008','6','379','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bazin','Herv�','Roman','J''ai lu','Souple','Vip?re au poing','','','0','256','','FAUX','FAUX','0');
INSERT INTO `tmp` VALUES ('Lef�bre','Fran�oise','Roman','J''ai lu','Souple','Le petit prince cannibale','1991','','0','178','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Van Vogt','A.E.','Science-fiction','J''ai lu','Molle','Au-del? du village enchant?','09/06/1905','','0','313','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('S�chan','Thierry','Bibliographie','J''ai lu','Souple','Georges Brassens. histoire d''une vie','1993','','0','368','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Robine','Marc','Bibliographie','J''ai lu','Souple','Georges Brassens. histoire d''une vie','15/06/1905','','0','368','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Blatrier','Jean Michel','Roman','Le foyer de Cachan','Souple','Le vieux reptile','1994','','0','191','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Gabriel','A.','Dictionnaire','Hatier','Cartonn?e rigide','Dictionnaire latin-fran?ais','1960','','0','751','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Herbert','Franck','Science-fiction','Presses Pocket','Souple','Le cycle de Dune : Les h?r?tiques de Dune','','','0','492','Le cycle de Dune','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Cartland','Barbara','Roman','Tr�visse','Cartonn?e recouverte','Que notre bonheur dure','1980','','0','247','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Cartland','Barbara','Roman','Tr�visse','Cartonn?e recouverte','L''enchantement du d?sert','1980','','0','215','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Samson','Isabelle et R�my','Guide pratique','Dargaud','Cartonn?e rigide','L''art des Bonsa?s','1985','','0','224','','VRAI','FAUX','0');
INSERT INTO `tmp` VALUES ('Krakowiak','Sacha','Informatique','Dargaud','Souple','Principe des systh?mes d''exploitation des ordinateurs','1985','','30','436','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Grisham','John','Suspence','Laffont Robert','Cartonn?e souple','Le testament','2000','37 012.00','7','445','','VRAI','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Laffont Robert','Cartonn?e souple','Le talisman des territoires : Talisman','24/06/1905','37 559.00','0','646','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Straub','Peter','Suspence','Laffont Robert','Cartonn?e souple','Le talisman des territoires : Talisman','24/06/1905','37 559.00','0','646','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Boissard','Janine','Roman','Laffont Robert','Cartonn?e recouverte','Une femme en blanc','18/06/1905','','0','494','Suivi de Jeanne R.','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Laffont Robert','Cartonn?e souple','Le talisman des territoires : Territoires','24/06/1905','30/10/2002','2','551','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Straub','Peter','Fantastique','Laffont Robert','Cartonn?e souple','Le talisman des territoires : Territoires','24/06/1905','30/10/2002','2','551','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Fierro','Alfred','Histoire','Laffont Robert','Souple','Histoire et dictionnaire de Paris','1996','','28','1580','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Chevalier','Jean','Dictionnaire','Laffont Robert','Cartonn?e rigide','Dictionnaires des symboles','04/06/1905','','0','1060','Mythes. r?ves. coutumes. gestes. formes. figures. couleurs. nombres.','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Gheerbrant','Alain','Dictionnaire','Laffont Robert','Cartonn?e rigide','Dictionnaires des symboles','1982','','0','1060','Mythes. r?ves. coutumes. gestes. formes. figures. couleurs. nombres.','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Herbert','Franck','Science-fiction','Laffont Robert','Souple','Le cycle de Dune : Dune 1','1965','22/04/2003','5','349','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Herbert','Franck','Science-fiction','Laffont Robert','Souple','Le cycle de Dune : Dune 2','18/05/1905','37 733.00','5','572','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Herbert','Franck','Science-fiction','Laffont Robert','Souple','Le cycle de Dune : Le Messie de Dune','02/06/1905','37 763.00','5','314','','VRAI','VRAI','-1');
INSERT INTO `tmp` VALUES ('Herbert','Franck','Science-fiction','Laffont Robert','Souple','Le cycle de Dune : Les enfants de Dune','05/06/1905','37 763.00','6','539','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Richaudeau','Fran�ois','Guide pratique','Centre d''�tude et de promotion de la lecture','Cartonn?e recouverte','M?thode de lecture pratique. tome 2','1966','','0','348','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Gauquelin','Michel et Fran�oise','Guide pratique','Centre d''�tude et de promotion de la lecture','Cartonn?e recouverte','M?thode de lecture pratique. tome 2','1966','','0','348','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Richaudeau','Fran�ois','Guide pratique','Centre d''�tude et de promotion de la lecture','Cartonn?e recouverte','M?thode de lecture rapide. tome 1','1966','','0','523','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Gauquelin','Michel et Fran�oise','Guide pratique','Centre d''�tude et de promotion de la lecture','Cartonn?e recouverte','M?thode de lecture rapide. tome 1','1966','','0','523','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Ramiandrisoa','Joana','Guide pratique','Editions Fixot','Cartonn?e souple','La m?thode Arthur','1992','','0','293','Comment d?velopper dans l''harmonie les capacit?s naturelles de votre enfant','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Thierry','Jean-Pierre','Documentaire','Editions Fixot','Cartonn?e souple','L''argent des fonctionnaires','1998','','0','225','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Kermel','Marie','Guide pratique','De Vecchi','Souple','Je mange sain. mais je mange bien','1987','','0','270','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Salavert','Marie-H�l�ne','Guide pratique','De Vecchi','Souple','Je mange sain. mais je mange bien','1987','','0','270','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Cousture','Arlette','Roman','Editions de La Table Ronde','Souple','Emilie','1988','','0','523','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('McCullough','Colleen','Roman','Colleen McCullough','Souple','Les oiseaux se cachent pour mourir','1982','','0','536','Frace Loisirs','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Su�tone','','Histoire','Jean de Bonnot','Cartonn?e renforc?e','Les vies des douzes C?sars. empereurs romains','1983','','0','325','Edition de qualit?. gravures. illustrations.','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Suspence','Librio','Souple','La ballade de la balle ?lastique + L''homme qui refusait de serrer la main','1995','','0','96','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Phythian','B.A.','Dictionnaire','Phythian B.A.','Cartonn?e recouverte','English Idioms','1986','','0','250','','VRAI','FAUX','0');
INSERT INTO `tmp` VALUES ('Bourin','Jeanne','Roman','Fran�ois Bourin','Cartonn?e recouverte','Les P?r?grines','1989','','0','446','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Selz','Reiner K.','Guide pratique','Selz �ditions','Cartonn?e rigide','Le guide de tout ce qui est gratuit','1993','','0','348','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bleu','Fran�oise','Guide pratique','Selz �ditions','Cartonn?e rigide','Le guide de tout ce qui est gratuit','1993','','0','348','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Flaubert','Gustave','Roman','Garnier fr�res','Cartonn?e','L''?ducation sentimentale','1964','','0','473','Marque pages en fil','VRAI','FAUX','0');
INSERT INTO `tmp` VALUES ('Travis','Robert','Policier','Fleuve noir','Souple','Pi?ge ? Naqoura','1996','','0','213','Lieutenant ZAC','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Courcel','Pierre','Policier','Fleuve noir','Souple','L''otage du d?l?gu?','1977','','0','219','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dard','Fr�d�ric','Policier','Fleuve noir','Cartonn?e souple','Napol?on Pommier','22/06/1905','37 559.00','1','319','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Clerc','Roger','Guide pratique','Cariscript','Molle','Yoga? Oui ? mais ? d?mystifier pour atteindre le r?el','1992','','13','208','','VRAI','VRAI','-1');
INSERT INTO `tmp` VALUES ('Golibert','Pierre','Histoire','Hachette litt�rature','Cartonn?e souple','Les paysans fran?ais','22/06/1905','36 937.00','14','295','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','VRAI','VRAI','-1');
INSERT INTO `tmp` VALUES ('Universalis','Encyclopaedia','Histoire','Encyclopaedia Universalis','Cartonn?e renforc?e','Miroir du moyen-?ge : 1/ Les ?v?nements','21/06/1905','36 927.00','24','382','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Universalis','Encyclopaedia','Histoire','Encyclopaedia Universalis','Cartonn?e renforc?e','Miroir du moyen-?ge : 2/ Institutions. Figurines. Savoirs','21/06/1905','36 927.00','24','383','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dard','Patrice','Policier','Librairie Arth�me Fayard','Cartonn?e souple','Un pompier nomm? B?ru','24/06/1905','37 559.00','2','276','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Coppens','Yves','Histoire','Librairie Arth�me Fayard','Cartonn?e souple','Le singe. l''Affrique et l''homme','22/06/1905','36 927.00','13','150','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Volkmann','Jean-Charles','Histoire','Editions Gisserot','Cartonn?e souple','Histoire de France','20/06/1905','05/02/2001','0','341','Offert avec l''abonnement. valeur de l''offre : 400.00 F).','VRAI','VRAI','0');
INSERT INTO `tmp` VALUES ('Delavier','Fr�d�ric','Guide pratique','Vigot','Souple','Guide des mouvements de musculation','23/06/1905','37 100.00','19','124','Planches et illustration en couleur.','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Aucun','Auteur','Guide pratique','Reader''s Digest','Cartonn?e renforc?e','Guide de la route','23/06/1905','37 055.00','34','500','Edition 2001. France routi?re et touristique','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Clerc','Roger','Guide pratique','Le courrier du livre','Souple','Diagnostic de la personnalit?','1989','','18','251','Une m?thode de psychologie objective','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('De Gans','Guy','Guide pratique','Editions Famot','Cartonn?e rigide','Tests et personnalit?','1978','','0','256','Notre personnalit? par les tests','VRAI','VRAI','-1');
INSERT INTO `tmp` VALUES ('Demazi�re','Raymonde','Guide pratique','Editions Famot','Cartonn?e rigide','Graphologie','1978','','0','251','Trait? de graphologie : le caract?re par l''?criture','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('de Laroche','Robert','Documentaire','Editions de l''Archipel','Souple','Paroles de chat','1999','','0','259','Documentaire romanc? sur les chats. tr?s bien fait.','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Aucun','Auteur','Dictionnaire','Oxford University Press','Cartonn?e recouverte','The Oxford reference dictionary','1989','','0','978','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Hourquin','Didier','Dictionnaire','Editions gammaprim','Souple','Anglais : grammaire. expression et m?thodes','1995','','0','108','Seconde. premi?re. terminale.','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Schmidt','Jo�l','Dictionnaire','Larousse-Bordas','Cartonn?e rigide','Dictionnaire de la mythologie gr?que et romaine','1998','','0','206','','VRAI','VRAI','-1');
INSERT INTO `tmp` VALUES ('Aucun','Auteur','Dictionnaire','Guild Publishing London','Cartonn?e recouverte','The MacMillan Encyclopedia','1989','','0','1336','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dorseuil','Alain','Informatique','Micro Application','Souple','VB.NET','24/06/1905','37 590.00','1','368','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Club','Souple','La tour sombre 1 : Le pistolero','04/06/1905','38 696.00','15','255','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Club','Souple','La tour sombre 2 : Terres perdues','13/06/1905','38 696.00','21','522','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Club','Souple','La tour sombre 3 : Les trois cartes','09/06/1905','38 696.00','19','399','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Club','Souple','La tour sombre 4 : Magie et cristal','19/06/1905','38 696.00','24','863','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Club','Souple','La tour sombre 5 : Les loups de la Calla','25/06/1905','38 696.00','23','668','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Club','Souple','La tour sombre 6 : Le chant de Susannah','26/06/1905','38 696.00','21','525','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Club','Souple','La tour sombre 7 : La Tour Sombre','26/06/1905','38 696.00','29','953','','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('All�gre','Claude','Science','Editions Fayard','Souple','Un peu plus de science pour tout le monde','28/06/1905','39 085.00','23','511','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dard','Patrice','Policier','Editions Fayard','Souple','San-Antonio contre San-Antonio','28/06/1905','39 085.00','15','306','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dard','Patrice','Policier','Editions Fayard','Souple','San-Antonio Shocking!','28/06/1905','39 085.00','15','270','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dard','Patrice','Policier','Editions Fayard','Souple','San-Antonio Vingt mille n?uds sous les mers','28/06/1905','39 085.00','15','297','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dard','Patrice','Policier','Editions Fayard','Souple','San-Antono s''envole en l''air','29/06/1905','39 527.00','15','297','','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Young','Robyn','Suspence','Le Grand Livre du Mois','Cartonn?e souple','L''?me du temple : Le Livre du Cercle','02/07/1905','40 471.00','21','727','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Christie','Agatha','Policier','Le Grand Livre du Mois','Cartonn?e recouverte','T6 : Les ann?es 1938-1940','25/06/1905','38 961.00','23','1182','Rendez-vaous avec la mort.\r\nLe no?l d''Hercule Poirot.\r\nUn meurtre est-il facile ?\r\nDix petits n?gres.\r\nUn. deux. trois.\r\nJe ne suis pas coupable.','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Christie','Agatha','Policier','Le Grand Livre du Mois','Cartonn?e recouverte','T2 : Les ann?es 1926-1930','25/06/1905','38 961.00','22','1264','Le meurtre de Roger Ackroyd.\r\nLes quatre.\r\nLe train bleu.\r\nLes sept cadrans.\r\nLe crime est notre affaire.\r\nL''affaire protheroe.','FAUX','VRAI','-1');
INSERT INTO `tmp` VALUES ('Christie','Agatha','Policier','Le Grand Livre du Mois','Cartonn?e recouverte','T1 : Les ann?es 1920-1925','25/06/1905','38 961.00','23','1301','La myst?rieuse affaire de styles.\r\nMr Brown.\r\nLe crime du golf.\r\nL''homme au complet marron.\r\nLes enqu?tes d''Hercule Poirot.\r\nLe secret de Chimneys.','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Christie','Agatha','Policier','Le Grand Livre du Mois','Cartonn?e recouverte','T9 : Les ann?es 1949-1953','25/06/1905','39 289.00','23','1205','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Albouy','Vincent','Documentaire','Le Grand Livre du Mois','Souple','Les oiseaux du jardin','30/06/1905','40 471.00','19','128','Achat de 2 livre dont 1 offert ? Isabelle pour son anniversaire.\r\n+ CD audio de chants d''oiseaux.','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dubois','Philippe J.','Documentaire','Le Grand Livre du Mois','Souple','La passion des oiseaux','02/07/1905','40 471.00','29','332','Offre ? Isabelle pour son anniversaire','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Duquet','Marc','Documentaire','Le Grand Livre du Mois','Souple','La passion des oiseaux','02/07/1905','40 471.00','29','332','Offre ? Isabelle pour son anniversaire','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('Glaister','Lesley','Policier','Belfond','Souple','Soleil de plomb','28/06/1905','39 289.00','19','418','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Thibaux','Jean-Michel','Roman','Editions Presse cit�','Souple','La pyramide perdue','28/06/1905','39 289.00','19','338','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Calabre','Isabelle','Bibliographie','Parigramme','Souple','Les lieux cultes des ?crivains','30/06/1905','39 527.00','0','64','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Ludlum','Robert','Policier','Editions Grasset','Souple','La vendetta Lazare','28/06/1905','39 527.00','19','392','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Larkin','Patrick','Policier','Editions Grasset','Souple','La vendetta Lazare','28/06/1905','39 527.00','19','392','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Graham','Patrick','Suspence','Anne Carri�re','Souple','L''?vangile selon Satan','29/06/1905','39 527.00','21','526','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bachmann','Richard','Suspence','Le Livre de poche','Souple','Running man','04/06/1905','40 688.00','5','316','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Roman','Le Livre de poche','Souple','Un tour sur le Bolid''','22/06/1905','39 800.00','2','95','Titre original : Riding the bullet','FAUX','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Fantastique','Le Livre de poche','Souple','Dreamcatcher','25/06/1905','40 688.00','7','886','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Bensa�d','Norbert','Sant�','Seuil','Souple','Le sommeil de la raison. une m?thode : les m?decines douces','1988','','0','270','','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('King','Stephen','Essais - �tudes','Magnard','Souple','La Cadillac de Dolan','15/06/1905','40 688.00','4','142','Etude litt?raire','VRAI','FAUX','-1');
INSERT INTO `tmp` VALUES ('Dramert','Val�rie','Documentaire','Rustica �ditions','Cartonn?e souple','D?codez le langage de votre chat !','01/07/1905','40 848.00','14','111','Achet? 2. dont 1 pour offrir ? Isabelle','FAUX','FAUX','-1');


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `auth_key` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `password_hash` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `password_reset_token` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `email` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '10',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

INSERT INTO `user` VALUES ('1','sa','','','ezs824','','10','2015-05-29 18:46:58','0000-00-00 00:00:00');
